// API Helper Functions - COMPLETE VERSION
const API_BASE_URL = "http://localhost:5000/api"

// Helper function for regular API calls (JSON)
const apiCall = async (endpoint, options = {}) => {
  try {
    console.log(`🔄 Making API call to: ${API_BASE_URL}${endpoint}`)

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    })

    console.log(`📥 Response status: ${response.status}`)

    const data = await response.json()
    console.log("📥 Response data:", data)

    return data
  } catch (error) {
    console.error("❌ API call error:", error)
    return {
      success: false,
      message: "Network error. Please check if your backend server is running on http://localhost:5000",
    }
  }
}

// Helper function for file upload API calls (FormData)
const apiCallWithFile = async (endpoint, formData, token = null) => {
  try {
    console.log(`🔄 Making file upload API call to: ${API_BASE_URL}${endpoint}`)

    const headers = {}
    if (token) {
      headers.Authorization = `Bearer ${token}`
    }
    // Don't set Content-Type for FormData - browser will set it automatically with boundary

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: "POST",
      headers,
      body: formData,
    })

    console.log(`📥 Response status: ${response.status}`)

    const data = await response.json()
    console.log("📥 Response data:", data)

    return data
  } catch (error) {
    console.error("❌ File upload API call error:", error)
    return {
      success: false,
      message: "Network error. Please check if your backend server is running on http://localhost:5000",
    }
  }
}

// ===== AUTHENTICATION =====
export const signupUser = async (userData) => {
  console.log("👤 Signing up user:", userData.email)
  return await apiCall("/auth/signup/user", {
    method: "POST",
    body: JSON.stringify(userData),
  })
}

export const signupMentor = async (mentorData) => {
  console.log("👨‍🏫 Signing up mentor:", mentorData.email)
  return await apiCall("/auth/signup/mentor", {
    method: "POST",
    body: JSON.stringify(mentorData),
  })
}

export const signin = async (email, password) => {
  console.log("🔐 Signing in user:", email)
  return await apiCall("/auth/signin", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  })
}

export const getUserProfile = async (token) => {
  return await apiCall("/auth/profile", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

// ===== PROFILE MANAGEMENT =====
export const updateProfile = async (formData, token) => {
  return await apiCallWithFile("/auth/profile", formData, token)
}

export const changePassword = async (currentPassword, newPassword, token) => {
  return await apiCall("/auth/change-password", {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ currentPassword, newPassword }),
  })
}

// ===== LEARNING PROGRESS =====
export const enrollInCourse = async (courseId, token) => {
  return await apiCall(`/learning/enroll/${courseId}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const accessMaterial = async (materialId, token) => {
  return await apiCall(`/learning/access-material/${materialId}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const updateLearningProgress = async (progressId, progressData, token) => {
  return await apiCall(`/learning/progress/${progressId}`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(progressData),
  })
}

export const getMyLearning = async (token, type = null, status = null) => {
  const params = new URLSearchParams()
  if (type) params.append("type", type)
  if (status) params.append("status", status)

  return await apiCall(`/learning/my-learning?${params}`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const submitReview = async (progressId, rating, review, token) => {
  return await apiCall(`/learning/review/${progressId}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ rating, review }),
  })
}

// ===== MENTOR DASHBOARD =====
export const getMentorDashboard = async (token) => {
  return await apiCall("/mentor/dashboard", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const getMentorCourses = async (token) => {
  return await apiCall("/mentor/courses", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const createCourse = async (courseData, token) => {
  const formData = new FormData()

  formData.append("title", courseData.title)
  formData.append("description", courseData.description)
  formData.append("category", courseData.category)
  formData.append("difficulty", courseData.difficulty)
  formData.append("duration", courseData.duration)
  formData.append("language", courseData.language)

  if (courseData.courseVideo) {
    formData.append("courseVideo", courseData.courseVideo)
  }

  return await apiCallWithFile("/mentor/courses", formData, token)
}

export const updateCourse = async (courseId, courseData, token) => {
  const formData = new FormData()

  Object.keys(courseData).forEach((key) => {
    if (key === "courseVideo" && courseData[key]) {
      formData.append("courseVideo", courseData[key])
    } else if (courseData[key] !== undefined) {
      formData.append(key, courseData[key])
    }
  })

  return await apiCallWithFile(`/mentor/courses/${courseId}`, formData, token)
}

export const deleteCourse = async (courseId, token) => {
  return await apiCall(`/mentor/courses/${courseId}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const getMentorMaterials = async (token) => {
  return await apiCall("/mentor/materials", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const uploadStudyMaterial = async (materialData, token) => {
  const formData = new FormData()

  formData.append("title", materialData.title)
  formData.append("description", materialData.description)
  formData.append("category", materialData.category)
  formData.append("type", materialData.type)
  formData.append("difficulty", materialData.difficulty)
  formData.append("language", materialData.language)
  formData.append("tags", materialData.tags)
  formData.append("isPublic", materialData.isPublic)

  if (materialData.materialFile) {
    formData.append("materialFile", materialData.materialFile)
  }

  return await apiCallWithFile("/mentor/materials", formData, token)
}

export const updateMaterial = async (materialId, materialData, token) => {
  const formData = new FormData()

  Object.keys(materialData).forEach((key) => {
    if (key === "materialFile" && materialData[key]) {
      formData.append("materialFile", materialData[key])
    } else if (materialData[key] !== undefined) {
      formData.append(key, materialData[key])
    }
  })

  return await apiCallWithFile(`/mentor/materials/${materialId}`, formData, token)
}

export const deleteMaterial = async (materialId, token) => {
  return await apiCall(`/mentor/materials/${materialId}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const getMentorPosts = async (token) => {
  return await apiCall("/mentor/posts", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const createForumPost = async (postData, token) => {
  const formData = new FormData()

  formData.append("title", postData.title)
  formData.append("content", postData.content)
  formData.append("category", postData.category)
  if (postData.tags) formData.append("tags", postData.tags)
  if (postData.isPinned) formData.append("isPinned", postData.isPinned)

  if (postData.attachments && postData.attachments.length > 0) {
    postData.attachments.forEach((file) => {
      formData.append("attachments", file)
    })
  }

  return await apiCallWithFile("/mentor/posts", formData, token)
}

export const updatePost = async (postId, postData, token) => {
  const formData = new FormData()

  Object.keys(postData).forEach((key) => {
    if (key === "attachments" && postData[key] && postData[key].length > 0) {
      postData[key].forEach((file) => {
        formData.append("attachments", file)
      })
    } else if (postData[key] !== undefined) {
      formData.append(key, postData[key])
    }
  })

  return await apiCallWithFile(`/mentor/posts/${postId}`, formData, token)
}

export const deletePost = async (postId, token) => {
  return await apiCall(`/mentor/posts/${postId}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const getMentorConnectionRequests = async (token) => {
  return await apiCall("/mentor/connection-requests", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const respondToConnectionRequest = async (requestId, status, responseMessage, token) => {
  return await apiCall(`/mentor/connection-requests/${requestId}`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ status, responseMessage }),
  })
}

// ===== NOTIFICATIONS =====
export const getNotifications = async (token) => {
  return await apiCall("/notifications", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const markNotificationAsRead = async (notificationId, token) => {
  return await apiCall(`/notifications/${notificationId}/read`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const markAllNotificationsAsRead = async (token) => {
  return await apiCall("/notifications/mark-all-read", {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

// ===== TOKEN MANAGEMENT =====
export const saveToken = (token) => {
  localStorage.setItem("authToken", token)
}

export const getToken = () => {
  return localStorage.getItem("authToken")
}

export const removeToken = () => {
  localStorage.removeItem("authToken")
}

export const getCurrentUser = () => {
  const token = getToken()
  if (!token) return null

  try {
    const payload = JSON.parse(atob(token.split(".")[1]))
    return payload
  } catch (error) {
    console.error("Error parsing token:", error)
    return null
  }
}

// ===== PUBLIC CONTENT ACCESS =====
export const getPublicCourses = async (page = 1, category = null, difficulty = null, search = null) => {
  const params = new URLSearchParams({ page })
  if (category) params.append("category", category)
  if (difficulty) params.append("difficulty", difficulty)
  if (search) params.append("search", search)

  return await apiCall(`/courses?${params}`)
}

export const getCourseById = async (courseId, token = null) => {
  const headers = {}
  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  return await apiCall(`/courses/${courseId}`, {
    method: "GET",
    headers,
  })
}

export const getPublicStudyMaterials = async (page = 1, category = null, type = null) => {
  const params = new URLSearchParams({ page })
  if (category) params.append("category", category)
  if (type) params.append("type", type)

  return await apiCall(`/courses/materials/public?${params}`)
}

export const getForumPosts = async (page = 1, category = null) => {
  const params = new URLSearchParams({ page })
  if (category) params.append("category", category)

  return await apiCall(`/forum/posts?${params}`)
}

export const getMentors = async (token) => {
  return await apiCall("/connections/mentors", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const sendConnectionRequest = async (mentorId, message, requestType, token) => {
  return await apiCall("/connections/send", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ mentorId, message, requestType }),
  })
}

export const likePost = async (postId, token) => {
  return await apiCall(`/forum/posts/${postId}/like`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  })
}

export const addComment = async (postId, content, token) => {
  return await apiCall(`/forum/posts/${postId}/comments`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ content }),
  })
}
