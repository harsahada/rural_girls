"use client"

import { useState } from "react"
import Navbar from "./components/Navbar.jsx"
import Home from "./components/Home.jsx"
import About from "./components/About.jsx"
import Contact from "./components/Contact.jsx"
import Auth from "./components/Auth.jsx"
import MyLearning from "./components/MyLearning.jsx"

function App() {
  const [activeSection, setActiveSection] = useState("home")
  const [showAuth, setShowAuth] = useState(false)

  const renderContent = () => {
    switch (activeSection) {
      case "home":
        return <Home />
      case "about":
        return <About />
      case "contact":
        return <Contact />
      case "mylearning":
        return <MyLearning />
      default:
        return <Home />
    }
  }

  return (
    <div className="App">
      <Navbar activeSection={activeSection} onSectionChange={setActiveSection} onAuthClick={() => setShowAuth(true)} />
      {showAuth && <Auth onClose={() => setShowAuth(false)} />}
      <main>{renderContent()}</main>
    </div>
  )
}

export default App
