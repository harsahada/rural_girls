// src/components/About.jsx

import React from "react";

const About = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">About Us</h2>
      <p>This is the About page of Rural Girls Empowerment Platform.</p>
    </div>
  );
};

export default About;
