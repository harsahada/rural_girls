"use client"

import { useState, useEffect } from "react"
import { MessageSquare, Heart, Eye, User, Clock, Pin } from "lucide-react"
import { getForumPosts, likePost, addComment, getToken, getCurrentUser } from "../api.js"
import "./Community.css"

const Community = () => {
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [currentUser, setCurrentUser] = useState(null)

  const categories = [
    "All",
    "Announcement",
    "Discussion",
    "Question",
    "Resource",
    "Success Story",
    "Tips & Tricks",
    "News",
    "Other",
  ]

  useEffect(() => {
    const user = getCurrentUser()
    setCurrentUser(user)
    fetchPosts()
  }, [])

  useEffect(() => {
    fetchPosts()
  }, [selectedCategory])

  const fetchPosts = async () => {
    try {
      setLoading(true)
      const response = await getForumPosts(1, selectedCategory === "All" ? null : selectedCategory)

      if (response.success) {
        setPosts(response.posts || [])
      } else {
        console.error("Failed to fetch posts:", response.message)
      }
    } catch (error) {
      console.error("Error fetching posts:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleLike = async (postId) => {
    if (!currentUser) {
      alert("Please sign in to like posts")
      return
    }

    try {
      const token = getToken()
      const response = await likePost(postId, token)

      if (response.success) {
        // Update the post in the local state
        setPosts(
          posts.map((post) => (post._id === postId ? { ...post, likes: response.likesCount || post.likes } : post)),
        )
      }
    } catch (error) {
      console.error("Error liking post:", error)
    }
  }

  return (
    <div className="community-page">
      {/* Hero Section */}
      <section className="community-hero">
        <div className="hero-content">
          <h1>Community Forum</h1>
          <p>Connect, share, and learn from our community of mentors and learners</p>
          <div className="hero-stats">
            <div className="stat">
              <h3>{posts.length}</h3>
              <p>Forum Posts</p>
            </div>
            <div className="stat">
              <h3>{categories.length - 1}</h3>
              <p>Categories</p>
            </div>
            <div className="stat">
              <h3>Active</h3>
              <p>Community</p>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="community-filters">
        <div className="container">
          <div className="filters">
            <div className="filter-group">
              <label>Category:</label>
              <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Posts Section */}
      <section className="posts-section">
        <div className="container">
          {loading ? (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Loading posts...</p>
            </div>
          ) : posts.length > 0 ? (
            <div className="posts-list">
              {posts.map((post) => (
                <PostCard key={post._id} post={post} currentUser={currentUser} onLike={handleLike} />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <MessageSquare size={64} />
              <h3>No posts found</h3>
              <p>
                {selectedCategory !== "All"
                  ? "No posts in this category yet"
                  : "No forum posts have been created yet. Check back soon!"}
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

// Post Card Component
const PostCard = ({ post, currentUser, onLike }) => {
  const [showComments, setShowComments] = useState(false)
  const [newComment, setNewComment] = useState("")
  const [submittingComment, setSubmittingComment] = useState(false)

  const handleAddComment = async (e) => {
    e.preventDefault()
    if (!currentUser) {
      alert("Please sign in to comment")
      return
    }

    if (!newComment.trim()) return

    try {
      setSubmittingComment(true)
      const token = getToken()
      const response = await addComment(post._id, newComment, token)

      if (response.success) {
        setNewComment("")
        // TODO: Update post comments in parent component
        alert("Comment added successfully!")
      }
    } catch (error) {
      console.error("Error adding comment:", error)
    } finally {
      setSubmittingComment(false)
    }
  }

  const getCategoryColor = (category) => {
    const colors = {
      announcement: "#ef4444",
      discussion: "#3b82f6",
      question: "#f59e0b",
      resource: "#10b981",
      "success story": "#8b5cf6",
      "tips & tricks": "#06b6d4",
      news: "#6366f1",
      other: "#64748b",
    }
    return colors[category?.toLowerCase()] || "#64748b"
  }

  return (
    <div className="post-card">
      <div className="post-header">
        <div className="post-title-section">
          <div className="post-badges">
            {post.isPinned && (
              <span className="pinned-badge">
                <Pin size={14} />
                Pinned
              </span>
            )}
            <span className="category-badge" style={{ backgroundColor: getCategoryColor(post.category) }}>
              {post.category}
            </span>
          </div>
          <h3>{post.title}</h3>
        </div>

        <div className="post-author">
          <User size={16} />
          <div>
            <span className="author-name">{post.author?.fullName}</span>
            <span className="author-role">{post.author?.role}</span>
          </div>
        </div>
      </div>

      <div className="post-content">
        <p>{post.content}</p>
      </div>

      {post.attachments && post.attachments.length > 0 && (
        <div className="post-attachments">
          <h4>Attachments:</h4>
          <div className="attachments-list">
            {post.attachments.map((attachment, index) => (
              <div key={index} className="attachment">
                <span className="attachment-icon">{attachment.fileType === "image" ? "🖼️" : "📎"}</span>
                <span className="attachment-name">{attachment.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="post-meta">
        <div className="post-stats">
          <button
            className={`stat-btn ${currentUser ? "interactive" : ""}`}
            onClick={() => currentUser && onLike(post._id)}
          >
            <Heart size={16} />
            <span>{post.likes?.length || 0}</span>
          </button>

          <div className="stat">
            <Eye size={16} />
            <span>{post.views || 0}</span>
          </div>

          <button className="stat-btn" onClick={() => setShowComments(!showComments)}>
            <MessageSquare size={16} />
            <span>{post.comments?.length || 0}</span>
          </button>
        </div>

        <div className="post-time">
          <Clock size={14} />
          <span>{new Date(post.createdAt).toLocaleDateString()}</span>
        </div>
      </div>

      {showComments && (
        <div className="comments-section">
          <div className="comments-list">
            {post.comments?.map((comment, index) => (
              <div key={index} className="comment">
                <div className="comment-author">
                  <User size={14} />
                  <span>{comment.author?.fullName}</span>
                  <span className="comment-time">{new Date(comment.createdAt).toLocaleDateString()}</span>
                </div>
                <p className="comment-content">{comment.content}</p>
              </div>
            ))}
          </div>

          {currentUser && (
            <form onSubmit={handleAddComment} className="comment-form">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                rows={3}
                required
              />
              <button type="submit" className="btn-primary" disabled={submittingComment}>
                {submittingComment ? "Posting..." : "Post Comment"}
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  )
}

export default Community
