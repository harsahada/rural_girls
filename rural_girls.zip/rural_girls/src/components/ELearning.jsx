"use client"

import { useState, useEffect } from "react"
import { BookOpen, Play, User, Clock, Star, Search } from "lucide-react"
import { getPublicCourses, getCurrentUser, enrollInCourse, getCourseById, getToken } from "../api.js"
import "./ELearning.css"

const ELearning = () => {
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedDifficulty, setSelectedDifficulty] = useState("All")
  const [currentUser, setCurrentUser] = useState(null)

  const categories = [
    "All",
    "Business",
    "Arts & Crafts",
    "Agriculture",
    "Health & Wellness",
    "Communication Skills",
    "Digital Marketing",
    "Tailoring & Fashion",
    "Cooking & Food Processing",
    "Technology",
    "Education",
    "Other",
  ]

  const difficulties = ["All", "Beginner", "Intermediate", "Advanced"]

  useEffect(() => {
    const user = getCurrentUser()
    setCurrentUser(user)
    fetchCourses()
  }, [])

  useEffect(() => {
    fetchCourses()
  }, [selectedCategory, selectedDifficulty, searchTerm])

  const fetchCourses = async () => {
    try {
      setLoading(true)
      const response = await getPublicCourses(
        1,
        selectedCategory === "All" ? null : selectedCategory,
        selectedDifficulty === "All" ? null : selectedDifficulty,
        searchTerm || null,
      )

      if (response.success) {
        setCourses(response.courses || [])
      } else {
        console.error("Failed to fetch courses:", response.message)
      }
    } catch (error) {
      console.error("Error fetching courses:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    fetchCourses()
  }

  return (
    <div className="elearning-page">
      {/* Hero Section */}
      <section className="elearning-hero">
        <div className="hero-content">
          <h1>E-Learning Courses</h1>
          <p>Learn new skills with video courses created by expert mentors</p>
          <div className="hero-stats">
            <div className="stat">
              <h3>{courses.length}</h3>
              <p>Available Courses</p>
            </div>
            <div className="stat">
              <h3>{categories.length - 1}</h3>
              <p>Categories</p>
            </div>
            <div className="stat">
              <h3>Expert</h3>
              <p>Mentors</p>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="search-filters">
        <div className="container">
          <form onSubmit={handleSearch} className="search-form">
            <div className="search-input">
              <Search size={20} />
              <input
                type="text"
                placeholder="Search courses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button type="submit" className="search-btn">
              Search
            </button>
          </form>

          <div className="filters">
            <div className="filter-group">
              <label>Category:</label>
              <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label>Difficulty:</label>
              <select value={selectedDifficulty} onChange={(e) => setSelectedDifficulty(e.target.value)}>
                {difficulties.map((difficulty) => (
                  <option key={difficulty} value={difficulty}>
                    {difficulty}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="courses-section">
        <div className="container">
          {loading ? (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Loading courses...</p>
            </div>
          ) : courses.length > 0 ? (
            <div className="courses-grid">
              {courses.map((course) => (
                <CourseCard key={course._id} course={course} currentUser={currentUser} />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <BookOpen size={64} />
              <h3>No courses found</h3>
              <p>
                {searchTerm || selectedCategory !== "All" || selectedDifficulty !== "All"
                  ? "Try adjusting your search filters"
                  : "No courses have been uploaded yet. Check back soon!"}
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

// Course Card Component
const CourseCard = ({ course, currentUser }) => {
  const handleEnroll = async () => {
    if (!currentUser) {
      alert("Please sign in to enroll in courses")
      return
    }

    try {
      const token = getToken()
      const response = await enrollInCourse(course._id, token)

      if (response.success) {
        alert("Successfully enrolled in course!")
        // Optionally refresh the course data or redirect to My Learning
      } else {
        alert(response.message || "Failed to enroll in course")
      }
    } catch (error) {
      console.error("Enrollment error:", error)
      alert("Failed to enroll in course")
    }
  }

  const handleViewCourse = async () => {
    if (!currentUser) {
      alert("Please sign in to view courses")
      return
    }

    try {
      const token = getToken()
      const response = await getCourseById(course._id, token)

      if (response.success) {
        // Open course viewer or redirect to course page
        alert("Course viewer will be implemented soon!")
      } else {
        alert("Failed to load course")
      }
    } catch (error) {
      console.error("View course error:", error)
      alert("Failed to load course")
    }
  }

  return (
    <div className="course-card">
      <div className="course-thumbnail">
        {course.videoUrl ? (
          <div className="video-thumbnail">
            <Play size={48} className="play-icon" />
            <span className="duration">{course.duration}</span>
          </div>
        ) : (
          <div className="no-video">
            <BookOpen size={48} />
          </div>
        )}
      </div>

      <div className="course-content">
        <div className="course-header">
          <h3>{course.title}</h3>
          <span className={`difficulty ${course.difficulty?.toLowerCase()}`}>{course.difficulty}</span>
        </div>

        <p className="course-description">{course.description}</p>

        <div className="course-meta">
          <div className="mentor-info">
            <User size={16} />
            <span>{course.mentor?.fullName}</span>
            {course.mentor?.jobTitle && <small>{course.mentor.jobTitle}</small>}
          </div>

          <div className="course-details">
            <div className="detail">
              <Clock size={16} />
              <span>{course.duration}</span>
            </div>
            <div className="detail">
              <BookOpen size={16} />
              <span>{course.category}</span>
            </div>
          </div>
        </div>

        <div className="course-stats">
          <div className="stat">
            <span>{course.enrolledUsers?.length || 0} enrolled</span>
          </div>
          <div className="stat">
            <span>{course.views || 0} views</span>
          </div>
          <div className="stat">
            <Star size={16} />
            <span>{course.likes?.length || 0}</span>
          </div>
        </div>

        <div className="course-actions">
          <button className="btn-secondary" onClick={handleViewCourse}>
            View Course
          </button>
          <button className="btn-primary" onClick={handleEnroll}>
            Enroll Now
          </button>
        </div>
      </div>
    </div>
  )
}

export default ELearning
