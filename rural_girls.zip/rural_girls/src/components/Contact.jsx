// src/components/Contact.jsx

import React from "react";

const Contact = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Contact Us</h2>
      <p>For any inquiries or support, email us at <b>support@ruralgirls.org</b></p>
    </div>
  );
};

export default Contact;
