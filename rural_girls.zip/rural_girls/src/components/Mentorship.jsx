"use client"

import { useState, useEffect } from "react"
import { Users, Briefcase, Send, User } from "lucide-react"
import { getMentors, sendConnectionRequest, getToken, getCurrentUser } from "../api.js"
import "./Mentorship.css"

const Mentorship = () => {
  const [mentors, setMentors] = useState([])
  const [loading, setLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState(null)
  const [showRequestModal, setShowRequestModal] = useState(false)
  const [selectedMentor, setSelectedMentor] = useState(null)

  useEffect(() => {
    const user = getCurrentUser()
    setCurrentUser(user)
    fetchMentors()
  }, [])

  const fetchMentors = async () => {
    try {
      setLoading(true)
      const token = getToken()
      const response = await getMentors(token)

      if (response.success) {
        setMentors(response.mentors || [])
      } else {
        console.error("Failed to fetch mentors:", response.message)
      }
    } catch (error) {
      console.error("Error fetching mentors:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleConnectRequest = (mentor) => {
    if (!currentUser) {
      alert("Please sign in to connect with mentors")
      return
    }

    if (currentUser.role === "mentor") {
      alert("Mentors cannot send connection requests to other mentors")
      return
    }

    setSelectedMentor(mentor)
    setShowRequestModal(true)
  }

  return (
    <div className="mentorship-page">
      {/* Hero Section */}
      <section className="mentorship-hero">
        <div className="hero-content">
          <h1>Find Your Mentor</h1>
          <p>Connect with experienced mentors who can guide your journey</p>
          <div className="hero-stats">
            <div className="stat">
              <h3>{mentors.length}</h3>
              <p>Expert Mentors</p>
            </div>
            <div className="stat">
              <h3>Various</h3>
              <p>Industries</p>
            </div>
            <div className="stat">
              <h3>Free</h3>
              <p>Connections</p>
            </div>
          </div>
        </div>
      </section>

      {/* Mentors Section */}
      <section className="mentors-section">
        <div className="container">
          <div className="section-header">
            <h2>Available Mentors</h2>
            <p>Browse through our community of expert mentors</p>
          </div>

          {loading ? (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Loading mentors...</p>
            </div>
          ) : mentors.length > 0 ? (
            <div className="mentors-grid">
              {mentors.map((mentor) => (
                <MentorCard
                  key={mentor._id}
                  mentor={mentor}
                  currentUser={currentUser}
                  onConnect={handleConnectRequest}
                />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <Users size={64} />
              <h3>No mentors available</h3>
              <p>No mentors have joined the platform yet. Check back soon!</p>
            </div>
          )}
        </div>
      </section>

      {/* Connection Request Modal */}
      {showRequestModal && selectedMentor && (
        <ConnectionRequestModal
          mentor={selectedMentor}
          currentUser={currentUser}
          onClose={() => {
            setShowRequestModal(false)
            setSelectedMentor(null)
          }}
        />
      )}
    </div>
  )
}

// Mentor Card Component
const MentorCard = ({ mentor, currentUser, onConnect }) => {
  return (
    <div className="mentor-card">
      <div className="mentor-header">
        <div className="mentor-avatar">
          <User size={32} />
        </div>
        <div className="mentor-info">
          <h3>{mentor.fullName}</h3>
          <p className="job-title">{mentor.jobTitle}</p>
          {mentor.industry && <p className="industry">{mentor.industry}</p>}
        </div>
      </div>

      <div className="mentor-experience">
        <div className="experience-item">
          <Briefcase size={16} />
          <span>{mentor.experience}</span>
        </div>
      </div>

      {mentor.goals && (
        <div className="mentor-goals">
          <h4>Mentoring Goals:</h4>
          <p>{mentor.goals}</p>
        </div>
      )}

      <div className="mentor-actions">
        <button
          className="btn-primary"
          onClick={() => onConnect(mentor)}
          disabled={!currentUser || currentUser.role === "mentor"}
        >
          <Send size={16} />
          Connect
        </button>
      </div>
    </div>
  )
}

// Connection Request Modal Component
const ConnectionRequestModal = ({ mentor, currentUser, onClose }) => {
  const [formData, setFormData] = useState({
    message: "",
    requestType: "mentorship",
  })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const token = getToken()
      const response = await sendConnectionRequest(mentor._id, formData.message, formData.requestType, token)

      if (response.success) {
        alert("Connection request sent successfully!")
        onClose()
      } else {
        alert(response.message || "Failed to send connection request")
      }
    } catch (error) {
      console.error("Error sending connection request:", error)
      alert("Failed to send connection request")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Connect with {mentor.fullName}</h3>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="mentor-preview">
          <div className="mentor-avatar">
            <User size={24} />
          </div>
          <div>
            <h4>{mentor.fullName}</h4>
            <p>{mentor.jobTitle}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="connection-form">
          <div className="form-group">
            <label>Request Type</label>
            <select
              value={formData.requestType}
              onChange={(e) => setFormData({ ...formData, requestType: e.target.value })}
            >
              <option value="mentorship">Mentorship</option>
              <option value="collaboration">Collaboration</option>
              <option value="networking">Networking</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label>Message (Optional)</label>
            <textarea
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Introduce yourself and explain why you'd like to connect..."
              rows={4}
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Sending..." : "Send Request"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default Mentorship
