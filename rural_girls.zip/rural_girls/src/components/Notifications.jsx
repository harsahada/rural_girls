"use client"

import { useState } from "react"
import { Bell, Check, X, User, MessageSquare, UserCheck, UserX } from "lucide-react"
import { markNotificationAsRead, markAllNotificationsAsRead, getToken } from "../api.js"
import "./Notifications.css"

const Notifications = ({ notifications, onClose, onRefresh }) => {
  const [loading, setLoading] = useState(false)

  const handleMarkAsRead = async (notificationId) => {
    try {
      const token = getToken()
      const response = await markNotificationAsRead(notificationId, token)
      if (response.success) {
        onRefresh()
      }
    } catch (error) {
      console.error("Failed to mark notification as read:", error)
    }
  }

  const handleMarkAllAsRead = async () => {
    try {
      setLoading(true)
      const token = getToken()
      const response = await markAllNotificationsAsRead(token)
      if (response.success) {
        onRefresh()
      }
    } catch (error) {
      console.error("Failed to mark all notifications as read:", error)
    } finally {
      setLoading(false)
    }
  }

  const getNotificationIcon = (type) => {
    switch (type) {
      case "connection_request":
        return <User size={20} className="notification-icon connection" />
      case "connection_accepted":
        return <UserCheck size={20} className="notification-icon success" />
      case "connection_rejected":
        return <UserX size={20} className="notification-icon error" />
      case "course_enrollment":
        return <MessageSquare size={20} className="notification-icon info" />
      default:
        return <Bell size={20} className="notification-icon default" />
    }
  }

  const formatTime = (dateString) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInMinutes = Math.floor((now - date) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`
    return `${Math.floor(diffInMinutes / 1440)}d ago`
  }

  return (
    <div className="notifications-panel">
      <div className="notifications-header">
        <div className="header-left">
          <Bell size={20} />
          <h3>Notifications</h3>
          {notifications.filter((n) => !n.isRead).length > 0 && (
            <span className="unread-badge">{notifications.filter((n) => !n.isRead).length}</span>
          )}
        </div>
        <div className="header-actions">
          {notifications.filter((n) => !n.isRead).length > 0 && (
            <button type="button" className="mark-all-btn" onClick={handleMarkAllAsRead} disabled={loading}>
              <Check size={16} />
              Mark all read
            </button>
          )}
          <button type="button" className="close-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>
      </div>

      <div className="notifications-list">
        {notifications.length === 0 ? (
          <div className="empty-notifications">
            <Bell size={48} />
            <h4>No notifications yet</h4>
            <p>You'll see notifications here when you have updates</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <div
              key={notification._id}
              className={`notification-item ${!notification.isRead ? "unread" : ""}`}
              onClick={() => !notification.isRead && handleMarkAsRead(notification._id)}
            >
              <div className="notification-content">
                <div className="notification-header">
                  {getNotificationIcon(notification.type)}
                  <div className="notification-text">
                    <h4>{notification.title}</h4>
                    <p>{notification.message}</p>
                  </div>
                  {!notification.isRead && <div className="unread-dot"></div>}
                </div>
                <div className="notification-footer">
                  <span className="notification-time">{formatTime(notification.createdAt)}</span>
                  {notification.data?.mentorPhone && (
                    <span className="mentor-contact">📞 {notification.data.mentorPhone}</span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default Notifications
