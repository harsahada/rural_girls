"use client"

import { useState, useEffect } from "react"
import {
  BookOpen,
  Users,
  MessageSquare,
  FileText,
  Plus,
  Eye,
  Heart,
  TrendingUp,
  Upload,
  Check,
  X,
  User,
  Clock,
  Mail,
} from "lucide-react"
import "./MentorDashboard.css"
import {
  getMentorDashboard,
  getMentorCourses,
  getMentorMaterials,
  getMentorPosts,
  createCourse,
  uploadStudyMaterial,
  createForumPost,
  getMentorConnectionRequests,
  respondToConnectionRequest,
  getToken,
} from "../api.js"

const MentorDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview")
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [connectionRequests, setConnectionRequests] = useState([])

  useEffect(() => {
    fetchDashboardData()
    fetchConnectionRequests()
  }, [])

  const fetchDashboardData = async () => {
    try {
      const token = getToken()
      if (!token) {
        alert("Please log in again")
        return
      }

      const response = await getMentorDashboard(token)

      if (response.success) {
        setDashboardData(response.data)
      } else {
        console.error("Dashboard error:", response.message)
        if (response.message.includes("token")) {
          alert("Session expired. Please log in again.")
        }
      }
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchConnectionRequests = async () => {
    try {
      const token = getToken()
      if (!token) return

      const response = await getMentorConnectionRequests(token)

      if (response.success) {
        setConnectionRequests(response.requests)
      }
    } catch (error) {
      console.error("Failed to fetch connection requests:", error)
    }
  }

  const handleConnectionResponse = async (requestId, status, responseMessage = "") => {
    try {
      const token = getToken()
      const response = await respondToConnectionRequest(requestId, status, responseMessage, token)

      if (response.success) {
        alert(`Connection request ${status} successfully!`)
        fetchConnectionRequests() // Refresh the list
      } else {
        alert(response.message || `Failed to ${status} request`)
      }
    } catch (error) {
      console.error(`Failed to ${status} request:`, error)
      alert(`Failed to ${status} request`)
    }
  }

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>
        <p>Loading your dashboard...</p>
      </div>
    )
  }

  return (
    <div className="mentor-dashboard">
      {/* Header */}
      <header className="dashboard-header">
        <div className="header-content">
          <h1>Mentor Dashboard</h1>
          <p>Manage your courses, content, and community</p>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="dashboard-nav">
        <button
          className={`nav-tab ${activeTab === "overview" ? "active" : ""}`}
          onClick={() => setActiveTab("overview")}
        >
          <TrendingUp size={20} />
          Overview
        </button>
        <button
          className={`nav-tab ${activeTab === "courses" ? "active" : ""}`}
          onClick={() => setActiveTab("courses")}
        >
          <BookOpen size={20} />
          E-Learning Courses
        </button>
        <button
          className={`nav-tab ${activeTab === "materials" ? "active" : ""}`}
          onClick={() => setActiveTab("materials")}
        >
          <FileText size={20} />
          Skills Materials
        </button>
        <button className={`nav-tab ${activeTab === "forum" ? "active" : ""}`} onClick={() => setActiveTab("forum")}>
          <MessageSquare size={20} />
          Community Posts
        </button>
        <button
          className={`nav-tab ${activeTab === "requests" ? "active" : ""}`}
          onClick={() => setActiveTab("requests")}
        >
          <Users size={20} />
          Connection Requests
          {connectionRequests.filter((r) => r.status === "pending").length > 0 && (
            <span className="request-badge">{connectionRequests.filter((r) => r.status === "pending").length}</span>
          )}
        </button>
      </nav>

      {/* Main Content */}
      <main className="dashboard-content">
        {activeTab === "overview" && <OverviewTab data={dashboardData} />}
        {activeTab === "courses" && <CoursesTab onRefresh={fetchDashboardData} />}
        {activeTab === "materials" && <MaterialsTab onRefresh={fetchDashboardData} />}
        {activeTab === "forum" && <ForumTab onRefresh={fetchDashboardData} />}
        {activeTab === "requests" && (
          <RequestsTab requests={connectionRequests} onResponse={handleConnectionResponse} />
        )}
      </main>
    </div>
  )
}

// Overview Tab Component
const OverviewTab = ({ data }) => {
  if (!data || !data.overview) {
    return (
      <div className="overview-tab">
        <div className="loading-state">
          <div className="loading-spinner"></div>
          <p>Loading overview data...</p>
        </div>
      </div>
    )
  }

  const { overview, recentActivity } = data

  return (
    <div className="overview-tab">
      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon courses">
            <BookOpen size={24} />
          </div>
          <div className="stat-content">
            <h3>{overview.totalCourses || 0}</h3>
            <p>E-Learning Courses</p>
            <span className="stat-detail">{overview.publishedCourses || 0} published</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon posts">
            <MessageSquare size={24} />
          </div>
          <div className="stat-content">
            <h3>{overview.totalPosts || 0}</h3>
            <p>Community Posts</p>
            <span className="stat-detail">Forum engagement</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon requests">
            <Users size={24} />
          </div>
          <div className="stat-content">
            <h3>{overview.pendingRequests || 0}</h3>
            <p>Pending Requests</p>
            <span className="stat-detail">Awaiting response</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon materials">
            <FileText size={24} />
          </div>
          <div className="stat-content">
            <h3>{overview.totalMaterials || 0}</h3>
            <p>Skills Materials</p>
            <span className="stat-detail">Study resources</span>
          </div>
        </div>
      </div>

      {/* Engagement Metrics */}
      <div className="engagement-section">
        <h2>Engagement Metrics</h2>
        <div className="metrics-grid">
          <div className="metric-card">
            <Eye size={20} />
            <div>
              <h4>{overview.totalViews || 0}</h4>
              <p>Total Views</p>
            </div>
          </div>
          <div className="metric-card">
            <Users size={20} />
            <div>
              <h4>{overview.totalEnrollments || 0}</h4>
              <p>Course Enrollments</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      {recentActivity && (
        <div className="recent-activity">
          <h2>Recent Activity</h2>

          {recentActivity.recentCourses && recentActivity.recentCourses.length > 0 && (
            <div className="activity-section">
              <h3>Recent Courses</h3>
              <div className="activity-list">
                {recentActivity.recentCourses.slice(0, 3).map((course) => (
                  <div key={course._id} className="activity-item">
                    <BookOpen size={16} />
                    <div>
                      <p className="activity-title">{course.title}</p>
                      <p className="activity-meta">Created {new Date(course.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {recentActivity.recentRequests && recentActivity.recentRequests.length > 0 && (
            <div className="activity-section">
              <h3>Recent Connection Requests</h3>
              <div className="activity-list">
                {recentActivity.recentRequests.slice(0, 3).map((request) => (
                  <div key={request._id} className="activity-item">
                    <Users size={16} />
                    <div>
                      <p className="activity-title">New connection request</p>
                      <p className="activity-meta">{new Date(request.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// Courses Tab Component (E-Learning)
const CoursesTab = ({ onRefresh }) => {
  const [courses, setCourses] = useState([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchCourses()
  }, [])

  const fetchCourses = async () => {
    try {
      const token = getToken()
      const response = await getMentorCourses(token)

      if (response.success) {
        setCourses(response.courses || [])
      } else {
        console.error("Courses error:", response.message)
      }
    } catch (error) {
      console.error("Failed to fetch courses:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="courses-tab">
      <div className="tab-header">
        <h2>E-Learning Courses (Videos Only)</h2>
        <button className="create-btn" onClick={() => setShowCreateForm(true)}>
          <Plus size={20} />
          Create New Course
        </button>
      </div>

      {showCreateForm && (
        <CreateCourseForm
          onClose={() => setShowCreateForm(false)}
          onSuccess={() => {
            setShowCreateForm(false)
            fetchCourses()
            onRefresh()
          }}
        />
      )}

      {loading ? (
        <div className="loading">Loading courses...</div>
      ) : (
        <div className="courses-grid">
          {courses.map((course) => (
            <CourseCard key={course._id} course={course} onUpdate={fetchCourses} />
          ))}
          {courses.length === 0 && (
            <div className="empty-state">
              <BookOpen size={48} />
              <h3>No courses yet</h3>
              <p>Create your first e-learning course with video content!</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// Materials Tab Component (Skills - Documents only)
const MaterialsTab = ({ onRefresh }) => {
  const [materials, setMaterials] = useState([])
  const [showUploadForm, setShowUploadForm] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchMaterials()
  }, [])

  const fetchMaterials = async () => {
    try {
      const token = getToken()
      const response = await getMentorMaterials(token)

      if (response.success) {
        setMaterials(response.materials || [])
      } else {
        console.error("Materials error:", response.message)
      }
    } catch (error) {
      console.error("Failed to fetch materials:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="materials-tab">
      <div className="tab-header">
        <h2>Skills Materials (PDF, PPT, DOC only)</h2>
        <button className="create-btn" onClick={() => setShowUploadForm(true)}>
          <Upload size={20} />
          Upload Material
        </button>
      </div>

      {showUploadForm && (
        <UploadMaterialForm
          onClose={() => setShowUploadForm(false)}
          onSuccess={() => {
            setShowUploadForm(false)
            fetchMaterials()
            onRefresh()
          }}
        />
      )}

      {loading ? (
        <div className="loading">Loading materials...</div>
      ) : (
        <div className="materials-grid">
          {materials.map((material) => (
            <MaterialCard key={material._id} material={material} />
          ))}
          {materials.length === 0 && (
            <div className="empty-state">
              <FileText size={48} />
              <h3>No materials yet</h3>
              <p>Upload your first study material (PDF, PPT, DOC) to help students learn!</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// Forum Tab Component (Community - Images allowed)
const ForumTab = ({ onRefresh }) => {
  const [posts, setPosts] = useState([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPosts()
  }, [])

  const fetchPosts = async () => {
    try {
      const token = getToken()
      const response = await getMentorPosts(token)

      if (response.success) {
        setPosts(response.posts || [])
      } else {
        console.error("Posts error:", response.message)
      }
    } catch (error) {
      console.error("Failed to fetch posts:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="forum-tab">
      <div className="tab-header">
        <h2>Community Forum Posts (Images & Documents)</h2>
        <button className="create-btn" onClick={() => setShowCreateForm(true)}>
          <Plus size={20} />
          Create Post
        </button>
      </div>

      {showCreateForm && (
        <CreatePostForm
          onClose={() => setShowCreateForm(false)}
          onSuccess={() => {
            setShowCreateForm(false)
            fetchPosts()
            onRefresh()
          }}
        />
      )}

      {loading ? (
        <div className="loading">Loading posts...</div>
      ) : (
        <div className="posts-grid">
          {posts.map((post) => (
            <PostCard key={post._id} post={post} />
          ))}
          {posts.length === 0 && (
            <div className="empty-state">
              <MessageSquare size={48} />
              <h3>No posts yet</h3>
              <p>Create your first forum post to engage with the community!</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// Course Card Component
const CourseCard = ({ course, onUpdate, onEdit, onDelete }) => {
  const handleEdit = () => {
    if (onEdit) onEdit(course)
  }

  const handleDelete = async () => {
    if (window.confirm(`Are you sure you want to delete "${course.title}"?`)) {
      try {
        // TODO: Implement delete course API
        alert("Delete functionality will be implemented soon")
        if (onDelete) onDelete(course._id)
      } catch (error) {
        console.error("Failed to delete course:", error)
        alert("Failed to delete course")
      }
    }
  }

  return (
    <div className="course-card">
      <div className="course-header">
        <h3>{course.title}</h3>
        <span className={`status ${course.isPublished ? "published" : "draft"}`}>
          {course.isPublished ? "Published" : "Draft"}
        </span>
      </div>

      <p className="course-description">{course.description}</p>

      <div className="course-meta">
        <span className="category">{course.category}</span>
        <span className="difficulty">{course.difficulty}</span>
        <span className="duration">{course.duration}</span>
      </div>

      <div className="course-stats">
        <div className="stat">
          <Users size={16} />
          <span>{course.enrolledUsers?.length || 0} enrolled</span>
        </div>
        <div className="stat">
          <Eye size={16} />
          <span>{course.views || 0} views</span>
        </div>
        <div className="stat">
          <Heart size={16} />
          <span>{course.likes?.length || 0} likes</span>
        </div>
      </div>

      <div className="course-actions">
        <button className="btn-secondary" onClick={handleEdit}>
          Edit
        </button>
        <button className="btn-danger" onClick={handleDelete}>
          Delete
        </button>
        <button className="btn-primary">View</button>
      </div>
    </div>
  )
}

// Material Card Component
const MaterialCard = ({ material, onEdit, onDelete }) => {
  const handleEdit = () => {
    if (onEdit) onEdit(material)
  }

  const handleDelete = async () => {
    if (window.confirm(`Are you sure you want to delete "${material.title}"?`)) {
      try {
        // TODO: Implement delete material API
        alert("Delete functionality will be implemented soon")
        if (onDelete) onDelete(material._id)
      } catch (error) {
        console.error("Failed to delete material:", error)
        alert("Failed to delete material")
      }
    }
  }

  return (
    <div className="material-card">
      <div className="material-header">
        <h3>{material.title}</h3>
        <span className={`material-type ${material.type?.toLowerCase()}`}>{material.type}</span>
      </div>

      <p className="material-description">{material.description}</p>

      <div className="material-meta">
        <span className="category">{material.category}</span>
        <span className="difficulty">{material.difficulty}</span>
        <span className="visibility">{material.isPublic ? "Public" : "Private"}</span>
      </div>

      <div className="material-stats">
        <div className="stat">
          <Eye size={16} />
          <span>{material.views || 0} views</span>
        </div>
        <div className="stat">
          <Heart size={16} />
          <span>{material.likes?.length || 0} likes</span>
        </div>
      </div>

      <div className="material-actions">
        <button className="btn-secondary" onClick={handleEdit}>
          Edit
        </button>
        <button className="btn-danger" onClick={handleDelete}>
          Delete
        </button>
        <button className="btn-primary">View</button>
      </div>
    </div>
  )
}

// Post Card Component
const PostCard = ({ post }) => {
  return (
    <div className="post-card">
      <div className="post-header">
        <h3>{post.title}</h3>
        <div className="post-badges">
          <span className={`category-badge ${post.category?.toLowerCase().replace(/\s+/g, "-")}`}>{post.category}</span>
          {post.isPinned && <span className="pinned-badge">Pinned</span>}
        </div>
      </div>

      <p className="post-content">{post.content?.substring(0, 150)}...</p>

      <div className="post-stats">
        <div className="stat">
          <Eye size={16} />
          <span>{post.views || 0} views</span>
        </div>
        <div className="stat">
          <Heart size={16} />
          <span>{post.likes?.length || 0} likes</span>
        </div>
        <div className="stat">
          <MessageSquare size={16} />
          <span>{post.comments?.length || 0} comments</span>
        </div>
      </div>

      <div className="post-actions">
        <button className="btn-secondary">Edit</button>
        <button className="btn-primary">View</button>
      </div>
    </div>
  )
}

// Create Course Form Component (Videos only)
const CreateCourseForm = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    difficulty: "Beginner",
    duration: "",
    language: "English",
  })
  const [videoFile, setVideoFile] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      console.log("🎥 Selected video file:", file.name, "Type:", file.type)
      setVideoFile(file)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const token = getToken()
      if (!token) {
        alert("Please log in again")
        return
      }

      console.log("📤 Creating course:", formData.title)

      const courseData = { ...formData }
      if (videoFile) {
        courseData.courseVideo = videoFile
      }

      const response = await createCourse(courseData, token)

      if (response.success) {
        alert("Course created successfully!")
        onSuccess()
      } else {
        alert(response.message || "Failed to create course")
      }
    } catch (error) {
      console.error("Failed to create course:", error)
      alert("Failed to create course")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Create New E-Learning Course</h3>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="course-form">
          <div className="form-group">
            <label>Course Title *</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label>Description *</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Category *</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
              >
                <option value="">Select Category</option>
                <option value="Business">Business</option>
                <option value="Arts & Crafts">Arts & Crafts</option>
                <option value="Agriculture">Agriculture</option>
                <option value="Health & Wellness">Health & Wellness</option>
                <option value="Communication Skills">Communication Skills</option>
                <option value="Digital Marketing">Digital Marketing</option>
                <option value="Tailoring & Fashion">Tailoring & Fashion</option>
                <option value="Cooking & Food Processing">Cooking & Food Processing</option>
                <option value="Technology">Technology</option>
                <option value="Education">Education</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="form-group">
              <label>Difficulty</label>
              <select
                value={formData.difficulty}
                onChange={(e) => setFormData({ ...formData, difficulty: e.target.value })}
              >
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Duration *</label>
              <input
                type="text"
                placeholder="e.g., 2 hours, 1 week"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label>Language</label>
              <input
                type="text"
                value={formData.language}
                onChange={(e) => setFormData({ ...formData, language: e.target.value })}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Course Video (MP4, AVI, MOV only)</label>
            <input type="file" accept="video/mp4,video/avi,video/mov,video/wmv,video/flv" onChange={handleFileChange} />
            {videoFile && (
              <div className="file-preview">
                <p>Selected: {videoFile.name}</p>
                <p>Size: {(videoFile.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
            )}
            <small>Upload video files only for e-learning courses</small>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Creating..." : "Create Course"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// Upload Material Form Component (Documents only)
const UploadMaterialForm = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    type: "",
    difficulty: "Beginner",
    language: "English",
    tags: "",
    isPublic: true,
  })
  const [materialFile, setMaterialFile] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      console.log("📁 Selected file:", file.name, "Type:", file.type)
      setMaterialFile(file)

      // Auto-detect type based on file extension
      const extension = file.name.toLowerCase().split(".").pop()
      let detectedType = ""

      if (extension === "pdf") detectedType = "PDF"
      else if (["doc", "docx"].includes(extension)) detectedType = "Document"
      else if (["ppt", "pptx"].includes(extension)) detectedType = "Presentation"
      else if (["xls", "xlsx"].includes(extension)) detectedType = "Spreadsheet"

      if (detectedType && !formData.type) {
        setFormData((prev) => ({ ...prev, type: detectedType }))
      }
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const token = getToken()
      if (!token) {
        alert("Please log in again")
        return
      }

      if (!materialFile) {
        alert("Please select a file to upload")
        return
      }

      console.log("📤 Uploading material:", formData.title)

      const materialData = {
        ...formData,
        materialFile,
      }

      const response = await uploadStudyMaterial(materialData, token)

      if (response.success) {
        alert("Study material uploaded successfully!")
        onSuccess()
      } else {
        alert(response.message || "Failed to upload material")
      }
    } catch (error) {
      console.error("Failed to upload material:", error)
      alert("Failed to upload material")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Upload Skills Study Material</h3>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="material-form">
          <div className="form-group">
            <label>Title *</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label>Description *</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Category *</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
              >
                <option value="">Select Category</option>
                <option value="Business">Business</option>
                <option value="Arts & Crafts">Arts & Crafts</option>
                <option value="Agriculture">Agriculture</option>
                <option value="Health & Wellness">Health & Wellness</option>
                <option value="Communication Skills">Communication Skills</option>
                <option value="Digital Marketing">Digital Marketing</option>
                <option value="Tailoring & Fashion">Tailoring & Fashion</option>
                <option value="Cooking & Food Processing">Cooking & Food Processing</option>
                <option value="Technology">Technology</option>
                <option value="Education">Education</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="form-group">
              <label>Type *</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                required
              >
                <option value="">Select Type</option>
                <option value="PDF">PDF</option>
                <option value="Document">Word Document</option>
                <option value="Presentation">PowerPoint</option>
                <option value="Spreadsheet">Excel</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Difficulty</label>
              <select
                value={formData.difficulty}
                onChange={(e) => setFormData({ ...formData, difficulty: e.target.value })}
              >
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>

            <div className="form-group">
              <label>Language</label>
              <input
                type="text"
                value={formData.language}
                onChange={(e) => setFormData({ ...formData, language: e.target.value })}
              />
            </div>
          </div>

          <div className="form-group">
            <label>Tags (comma separated)</label>
            <input
              type="text"
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              placeholder="e.g., tutorial, beginner, practical"
            />
          </div>

          <div className="form-group">
            <label>File (PDF, DOC, PPT, XLS only) *</label>
            <input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx" onChange={handleFileChange} required />
            {materialFile && (
              <div className="file-preview">
                <p>Selected: {materialFile.name}</p>
                <p>Size: {(materialFile.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
            )}
            <small>Upload documents only for skills materials</small>
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={formData.isPublic}
                onChange={(e) => setFormData({ ...formData, isPublic: e.target.checked })}
              />
              Make this material public (visible to all users)
            </label>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Uploading..." : "Upload Material"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// Create Post Form Component (Images and documents allowed)
const CreatePostForm = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "",
    tags: "",
    isPinned: false,
  })
  const [attachments, setAttachments] = useState([])
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const token = getToken()
      if (!token) {
        alert("Please log in again")
        return
      }

      const postData = {
        ...formData,
        attachments,
      }

      const response = await createForumPost(postData, token)

      if (response.success) {
        alert("Post created successfully!")
        onSuccess()
      } else {
        alert(response.message || "Failed to create post")
      }
    } catch (error) {
      console.error("Failed to create post:", error)
      alert("Failed to create post")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Create Community Forum Post</h3>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="post-form">
          <div className="form-group">
            <label>Title *</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label>Content *</label>
            <textarea
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              rows={6}
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Category *</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
              >
                <option value="">Select Category</option>
                <option value="Announcement">Announcement</option>
                <option value="Discussion">Discussion</option>
                <option value="Question">Question</option>
                <option value="Resource">Resource</option>
                <option value="Success Story">Success Story</option>
                <option value="Tips & Tricks">Tips & Tricks</option>
                <option value="News">News</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="form-group">
              <label>Tags (comma separated)</label>
              <input
                type="text"
                value={formData.tags}
                onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                placeholder="e.g., beginner, tutorial, important"
              />
            </div>
          </div>

          <div className="form-group">
            <label>Attachments (Images & Documents)</label>
            <input
              type="file"
              multiple
              accept="image/*,.pdf,.doc,.docx,.ppt,.pptx"
              onChange={(e) => setAttachments(Array.from(e.target.files))}
            />
            <small>You can upload images and documents for community posts</small>
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={formData.isPinned}
                onChange={(e) => setFormData({ ...formData, isPinned: e.target.checked })}
              />
              Pin this post (will appear at the top)
            </label>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Creating..." : "Create Post"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// Requests Tab Component
const RequestsTab = ({ requests, onResponse }) => {
  const [responseMessage, setResponseMessage] = useState("")
  const [selectedRequest, setSelectedRequest] = useState(null)

  const handleResponse = (request, status) => {
    if (status === "accepted" && !responseMessage.trim()) {
      alert("Please provide a response message for accepted requests")
      return
    }

    onResponse(request._id, status, responseMessage)
    setResponseMessage("")
    setSelectedRequest(null)
  }

  const pendingRequests = requests.filter((r) => r.status === "pending")
  const processedRequests = requests.filter((r) => r.status !== "pending")

  return (
    <div className="requests-tab">
      <h2>Connection Requests</h2>

      {/* Pending Requests */}
      <div className="requests-section">
        <h3>Pending Requests ({pendingRequests.length})</h3>
        {pendingRequests.length === 0 ? (
          <div className="empty-state">
            <Users size={48} />
            <h4>No pending requests</h4>
            <p>New connection requests will appear here</p>
          </div>
        ) : (
          <div className="requests-grid">
            {pendingRequests.map((request) => (
              <div key={request._id} className="request-card pending">
                <div className="request-header">
                  <div className="user-info">
                    <User size={20} />
                    <div>
                      <h4>{request.from?.fullName}</h4>
                      <p>{request.from?.email}</p>
                    </div>
                  </div>
                  <span className="request-type">{request.requestType}</span>
                </div>

                {request.message && (
                  <div className="request-message">
                    <p>"{request.message}"</p>
                  </div>
                )}

                <div className="request-meta">
                  <div className="meta-item">
                    <Clock size={16} />
                    <span>{new Date(request.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="meta-item">
                    <Mail size={16} />
                    <span>{request.from?.role}</span>
                  </div>
                </div>

                <div className="request-actions">
                  <div className="response-input">
                    <textarea
                      placeholder="Add a response message (optional for rejection, required for acceptance)..."
                      value={selectedRequest === request._id ? responseMessage : ""}
                      onChange={(e) => {
                        setResponseMessage(e.target.value)
                        setSelectedRequest(request._id)
                      }}
                      rows={2}
                    />
                  </div>
                  <div className="action-buttons">
                    <button className="btn-reject" onClick={() => handleResponse(request, "rejected")}>
                      <X size={16} />
                      Reject
                    </button>
                    <button className="btn-accept" onClick={() => handleResponse(request, "accepted")}>
                      <Check size={16} />
                      Accept
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Processed Requests */}
      {processedRequests.length > 0 && (
        <div className="requests-section">
          <h3>Recent Responses ({processedRequests.length})</h3>
          <div className="requests-grid">
            {processedRequests.slice(0, 10).map((request) => (
              <div key={request._id} className={`request-card ${request.status}`}>
                <div className="request-header">
                  <div className="user-info">
                    <User size={20} />
                    <div>
                      <h4>{request.from?.fullName}</h4>
                      <p>{request.from?.email}</p>
                    </div>
                  </div>
                  <span className={`status-badge ${request.status}`}>{request.status}</span>
                </div>

                {request.responseMessage && (
                  <div className="response-message">
                    <p>
                      <strong>Your response:</strong> "{request.responseMessage}"
                    </p>
                  </div>
                )}

                <div className="request-meta">
                  <div className="meta-item">
                    <Clock size={16} />
                    <span>Responded: {new Date(request.respondedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default MentorDashboard
