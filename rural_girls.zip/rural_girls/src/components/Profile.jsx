"use client"

import { useState, useEffect } from "react"
import { User, Edit, Save, X, Camera, Lock, Eye, EyeOff, BookOpen } from "lucide-react"
import { getUserProfile, updateProfile, changePassword, getToken, removeToken } from "../api.js"
import "./Profile.css"

const Profile = ({ user, onClose, onLogout, onProfileUpdate }) => {
  const [profileData, setProfileData] = useState(null)
  const [isEditing, setIsEditing] = useState(false)
  const [isChangingPassword, setIsChangingPassword] = useState(false)
  const [editData, setEditData] = useState({})
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  })
  const [profilePicture, setProfilePicture] = useState(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetchProfile()
  }, [])

  const fetchProfile = async () => {
    try {
      const token = getToken()
      const response = await getUserProfile(token)

      if (response.success) {
        setProfileData(response.user)
        setEditData(response.user)
      }
    } catch (error) {
      console.error("Failed to fetch profile:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = () => {
    setIsEditing(true)
    setEditData({ ...profileData })
  }

  const handleProfilePictureChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setProfilePicture(file)
      // Create preview URL
      const previewUrl = URL.createObjectURL(file)
      setEditData({ ...editData, profilePicturePreview: previewUrl })
    }
  }

  const handleSave = async () => {
    try {
      setSaving(true)
      const token = getToken()

      const formData = new FormData()
      Object.keys(editData).forEach((key) => {
        if (key !== "profilePicturePreview" && editData[key] !== undefined) {
          if (Array.isArray(editData[key])) {
            formData.append(key, JSON.stringify(editData[key]))
          } else {
            formData.append(key, editData[key])
          }
        }
      })

      if (profilePicture) {
        formData.append("profilePicture", profilePicture)
      }

      const response = await updateProfile(formData, token)

      if (response.success) {
        setProfileData(response.user)
        setIsEditing(false)
        setProfilePicture(null)
        alert("Profile updated successfully!")
        if (onProfileUpdate) onProfileUpdate(response.user)
      } else {
        alert(response.message || "Failed to update profile")
      }
    } catch (error) {
      console.error("Failed to update profile:", error)
      alert("Failed to update profile")
    } finally {
      setSaving(false)
    }
  }

  const handleChangePassword = async () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert("New passwords don't match")
      return
    }

    if (passwordData.newPassword.length < 6) {
      alert("New password must be at least 6 characters long")
      return
    }

    try {
      setSaving(true)
      const token = getToken()
      const response = await changePassword(passwordData.currentPassword, passwordData.newPassword, token)

      if (response.success) {
        alert("Password changed successfully!")
        setIsChangingPassword(false)
        setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" })
      } else {
        alert(response.message || "Failed to change password")
      }
    } catch (error) {
      console.error("Failed to change password:", error)
      alert("Failed to change password")
    } finally {
      setSaving(false)
    }
  }

  const handleCancel = () => {
    setIsEditing(false)
    setIsChangingPassword(false)
    setEditData({ ...profileData })
    setPasswordData({ currentPassword: "", newPassword: "", confirmPassword: "" })
    setProfilePicture(null)
  }

  const handleLogout = () => {
    removeToken()
    onLogout()
    onClose()
  }

  const togglePasswordVisibility = (field) => {
    setShowPasswords((prev) => ({
      ...prev,
      [field]: !prev[field],
    }))
  }

  if (loading) {
    return (
      <div className="profile-overlay">
        <div className="profile-modal">
          <div className="profile-loading">
            <div className="loading-spinner"></div>
            <p>Loading profile...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="profile-overlay">
      <div className="profile-modal">
        <div className="profile-header">
          <h2>My Profile</h2>
          <button className="close-btn" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <div className="profile-content">
          {/* Profile Picture Section */}
          <div className="profile-picture-section">
            <div className="profile-picture">
              {editData.profilePicturePreview ? (
                <img src={editData.profilePicturePreview || "/placeholder.svg"} alt="Profile Preview" />
              ) : profileData?.profilePicture ? (
                <img src={`http://localhost:5000/uploads/${profileData.profilePicture}`} alt="Profile" />
              ) : (
                <User size={48} />
              )}
              {isEditing && (
                <label className="change-picture-btn">
                  <Camera size={16} />
                  <input type="file" accept="image/*" onChange={handleProfilePictureChange} hidden />
                </label>
              )}
            </div>
            <div className="profile-basic-info">
              <h3>{profileData?.fullName}</h3>
              <p className="role-badge">{profileData?.role}</p>
            </div>
          </div>

          {/* Profile Information */}
          <div className="profile-info">
            <div className="info-section">
              <h4>Basic Information</h4>
              <div className="info-grid">
                <div className="info-item">
                  <label>Full Name</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editData.fullName || ""}
                      onChange={(e) => setEditData({ ...editData, fullName: e.target.value })}
                    />
                  ) : (
                    <p>{profileData?.fullName}</p>
                  )}
                </div>

                <div className="info-item">
                  <label>Email</label>
                  <p>{profileData?.email}</p>
                  <small>Email cannot be changed</small>
                </div>

                {profileData?.role === "mentor" && (
                  <>
                    <div className="info-item">
                      <label>Phone</label>
                      {isEditing ? (
                        <input
                          type="tel"
                          value={editData.phone || ""}
                          onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.phone}</p>
                      )}
                    </div>

                    <div className="info-item">
                      <label>Job Title</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editData.jobTitle || ""}
                          onChange={(e) => setEditData({ ...editData, jobTitle: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.jobTitle}</p>
                      )}
                    </div>

                    <div className="info-item">
                      <label>Experience</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editData.experience || ""}
                          onChange={(e) => setEditData({ ...editData, experience: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.experience}</p>
                      )}
                    </div>

                    <div className="info-item">
                      <label>Industry</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editData.industry || ""}
                          onChange={(e) => setEditData({ ...editData, industry: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.industry || "Not specified"}</p>
                      )}
                    </div>
                  </>
                )}

                {profileData?.role === "user" && (
                  <>
                    <div className="info-item">
                      <label>State</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editData.state || ""}
                          onChange={(e) => setEditData({ ...editData, state: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.state}</p>
                      )}
                    </div>

                    <div className="info-item">
                      <label>Age</label>
                      {isEditing ? (
                        <input
                          type="number"
                          value={editData.age || ""}
                          onChange={(e) => setEditData({ ...editData, age: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.age}</p>
                      )}
                    </div>

                    <div className="info-item">
                      <label>Language</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editData.language || ""}
                          onChange={(e) => setEditData({ ...editData, language: e.target.value })}
                        />
                      ) : (
                        <p>{profileData?.language || "Not specified"}</p>
                      )}
                    </div>

                    <div className="info-item full-width">
                      <label>Interests</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={Array.isArray(editData.interests) ? editData.interests.join(", ") : ""}
                          onChange={(e) =>
                            setEditData({
                              ...editData,
                              interests: e.target.value.split(",").map((item) => item.trim()),
                            })
                          }
                          placeholder="Enter interests separated by commas"
                        />
                      ) : (
                        <div className="interests-display">
                          {profileData?.interests?.map((interest, index) => (
                            <span key={index} className="interest-tag">
                              {interest}
                            </span>
                          )) || <p>No interests specified</p>}
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>

            {profileData?.role === "mentor" && (
              <div className="info-section">
                <h4>Professional Details</h4>
                <div className="info-item full-width">
                  <label>Goals</label>
                  {isEditing ? (
                    <textarea
                      value={editData.goals || ""}
                      onChange={(e) => setEditData({ ...editData, goals: e.target.value })}
                      rows={3}
                    />
                  ) : (
                    <p>{profileData?.goals}</p>
                  )}
                </div>
              </div>
            )}

            {/* Password Change Section */}
            {isChangingPassword && (
              <div className="info-section">
                <h4>Change Password</h4>
                <div className="info-grid">
                  <div className="info-item">
                    <label>Current Password</label>
                    <div className="password-input">
                      <input
                        type={showPasswords.current ? "text" : "password"}
                        value={passwordData.currentPassword}
                        onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                      />
                      <button
                        type="button"
                        className="password-toggle"
                        onClick={() => togglePasswordVisibility("current")}
                      >
                        {showPasswords.current ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className="info-item">
                    <label>New Password</label>
                    <div className="password-input">
                      <input
                        type={showPasswords.new ? "text" : "password"}
                        value={passwordData.newPassword}
                        onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                      />
                      <button type="button" className="password-toggle" onClick={() => togglePasswordVisibility("new")}>
                        {showPasswords.new ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className="info-item">
                    <label>Confirm New Password</label>
                    <div className="password-input">
                      <input
                        type={showPasswords.confirm ? "text" : "password"}
                        value={passwordData.confirmPassword}
                        onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                      />
                      <button
                        type="button"
                        className="password-toggle"
                        onClick={() => togglePasswordVisibility("confirm")}
                      >
                        {showPasswords.confirm ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="profile-actions">
            {isEditing ? (
              <>
                <button className="btn-save" onClick={handleSave} disabled={saving}>
                  <Save size={16} />
                  {saving ? "Saving..." : "Save Changes"}
                </button>
                <button className="btn-cancel" onClick={handleCancel}>
                  Cancel
                </button>
              </>
            ) : isChangingPassword ? (
              <>
                <button className="btn-save" onClick={handleChangePassword} disabled={saving}>
                  <Lock size={16} />
                  {saving ? "Changing..." : "Change Password"}
                </button>
                <button className="btn-cancel" onClick={handleCancel}>
                  Cancel
                </button>
              </>
            ) : (
              <>
                <button className="btn-edit" onClick={handleEdit}>
                  <Edit size={16} />
                  Edit Profile
                </button>
                <button className="btn-password" onClick={() => setIsChangingPassword(true)}>
                  <Lock size={16} />
                  Change Password
                </button>
              </>
            )}

            {profileData?.role === "user" && (
              <button
                className="btn-learning"
                onClick={() => {
                  onClose()
                  // Navigate to My Learning section
                  if (window.setActiveSection) {
                    window.setActiveSection("mylearning")
                  }
                }}
              >
                <BookOpen size={16} />
                My Learning
              </button>
            )}

            <button className="btn-logout" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Profile
