import React from "react";

const Auth = () => {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Login / Register</h2>
      <p>Authentication form will go here.</p>
    </div>
  );
};

export default Auth;
