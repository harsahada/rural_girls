"use client"

import { useState, useEffect } from "react"
import { BookOpen, FileText, Play, Clock, Star, TrendingUp, Award } from "lucide-react"
import { getMyLearning, updateLearningProgress, submitReview, getToken } from "../api.js"
import "./MyLearning.css"

const MyLearning = () => {
  const [learningData, setLearningData] = useState(null)
  const [activeTab, setActiveTab] = useState("overview")
  const [loading, setLoading] = useState(true)
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState(null)

  useEffect(() => {
    fetchLearningData()
  }, [])

  const fetchLearningData = async () => {
    try {
      setLoading(true)
      const token = getToken()
      const response = await getMyLearning(token)

      if (response.success) {
        setLearningData(response.data)
      } else {
        console.error("Failed to fetch learning data:", response.message)
      }
    } catch (error) {
      console.error("Error fetching learning data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleProgressUpdate = async (progressId, progressValue) => {
    try {
      const token = getToken()
      const response = await updateLearningProgress(progressId, { progress: progressValue }, token)

      if (response.success) {
        fetchLearningData() // Refresh data
      }
    } catch (error) {
      console.error("Failed to update progress:", error)
    }
  }

  const handleReviewSubmit = async (rating, review) => {
    try {
      const token = getToken()
      const response = await submitReview(selectedItem._id, rating, review, token)

      if (response.success) {
        alert("Review submitted successfully!")
        setShowReviewModal(false)
        setSelectedItem(null)
        fetchLearningData()
      } else {
        alert("Failed to submit review")
      }
    } catch (error) {
      console.error("Failed to submit review:", error)
      alert("Failed to submit review")
    }
  }

  if (loading) {
    return (
      <div className="my-learning-loading">
        <div className="loading-spinner"></div>
        <p>Loading your learning progress...</p>
      </div>
    )
  }

  if (!learningData) {
    return (
      <div className="my-learning-error">
        <h3>Failed to load learning data</h3>
        <button onClick={fetchLearningData}>Try Again</button>
      </div>
    )
  }

  return (
    <div className="my-learning">
      {/* Header */}
      <header className="learning-header">
        <div className="header-content">
          <h1>My Learning Journey</h1>
          <p>Track your progress and continue learning</p>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="learning-nav">
        <button
          className={`nav-tab ${activeTab === "overview" ? "active" : ""}`}
          onClick={() => setActiveTab("overview")}
        >
          <TrendingUp size={20} />
          Overview
        </button>
        <button
          className={`nav-tab ${activeTab === "courses" ? "active" : ""}`}
          onClick={() => setActiveTab("courses")}
        >
          <BookOpen size={20} />
          Courses ({learningData.courses.length})
        </button>
        <button
          className={`nav-tab ${activeTab === "materials" ? "active" : ""}`}
          onClick={() => setActiveTab("materials")}
        >
          <FileText size={20} />
          Materials ({learningData.materials.length})
        </button>
      </nav>

      {/* Main Content */}
      <main className="learning-content">
        {activeTab === "overview" && <OverviewTab data={learningData} onProgressUpdate={handleProgressUpdate} />}
        {activeTab === "courses" && (
          <CoursesTab
            courses={learningData.courses}
            onProgressUpdate={handleProgressUpdate}
            onReview={(item) => {
              setSelectedItem(item)
              setShowReviewModal(true)
            }}
          />
        )}
        {activeTab === "materials" && (
          <MaterialsTab
            materials={learningData.materials}
            onProgressUpdate={handleProgressUpdate}
            onReview={(item) => {
              setSelectedItem(item)
              setShowReviewModal(true)
            }}
          />
        )}
      </main>

      {/* Review Modal */}
      {showReviewModal && selectedItem && (
        <ReviewModal
          item={selectedItem}
          onClose={() => {
            setShowReviewModal(false)
            setSelectedItem(null)
          }}
          onSubmit={handleReviewSubmit}
        />
      )}
    </div>
  )
}

// Overview Tab Component
const OverviewTab = ({ data }) => {
  const { stats, courses, materials } = data

  const recentActivity = [...courses, ...materials]
    .sort((a, b) => new Date(b.lastAccessed) - new Date(a.lastAccessed))
    .slice(0, 5)

  return (
    <div className="overview-tab">
      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card courses">
          <div className="stat-icon">
            <BookOpen size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.totalCourses}</h3>
            <p>Enrolled Courses</p>
            <span className="stat-detail">{stats.completedCourses} completed</span>
          </div>
        </div>

        <div className="stat-card materials">
          <div className="stat-icon">
            <FileText size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.totalMaterials}</h3>
            <p>Study Materials</p>
            <span className="stat-detail">{stats.completedMaterials} completed</span>
          </div>
        </div>

        <div className="stat-card time">
          <div className="stat-icon">
            <Clock size={24} />
          </div>
          <div className="stat-content">
            <h3>{Math.round(stats.totalTimeSpent / 60)}h</h3>
            <p>Time Spent</p>
            <span className="stat-detail">{stats.totalTimeSpent} minutes total</span>
          </div>
        </div>

        <div className="stat-card progress">
          <div className="stat-icon">
            <Award size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.completedCourses + stats.completedMaterials}</h3>
            <p>Completed Items</p>
            <span className="stat-detail">Keep learning!</span>
          </div>
        </div>
      </div>

      {/* Progress Overview */}
      <div className="progress-overview">
        <h2>Learning Progress</h2>
        <div className="progress-charts">
          <div className="progress-chart">
            <h3>Courses</h3>
            <div className="chart-container">
              <div className="progress-ring">
                <div className="progress-text">
                  {stats.totalCourses > 0 ? Math.round((stats.completedCourses / stats.totalCourses) * 100) : 0}%
                </div>
              </div>
            </div>
            <p>
              {stats.completedCourses} of {stats.totalCourses} completed
            </p>
          </div>

          <div className="progress-chart">
            <h3>Materials</h3>
            <div className="chart-container">
              <div className="progress-ring">
                <div className="progress-text">
                  {stats.totalMaterials > 0 ? Math.round((stats.completedMaterials / stats.totalMaterials) * 100) : 0}%
                </div>
              </div>
            </div>
            <p>
              {stats.completedMaterials} of {stats.totalMaterials} completed
            </p>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="recent-activity">
        <h2>Recent Activity</h2>
        {recentActivity.length > 0 ? (
          <div className="activity-list">
            {recentActivity.map((item) => (
              <div key={item._id} className="activity-item">
                <div className="activity-icon">
                  {item.type === "course" ? <BookOpen size={20} /> : <FileText size={20} />}
                </div>
                <div className="activity-content">
                  <h4>{item.course?.title || item.material?.title}</h4>
                  <p>Last accessed: {new Date(item.lastAccessed).toLocaleDateString()}</p>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${item.progress}%` }}></div>
                  </div>
                  <span className="progress-text">{item.progress}% complete</span>
                </div>
                <div className="activity-status">
                  <span className={`status ${item.status}`}>{item.status}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-activity">
            <BookOpen size={48} />
            <h3>No learning activity yet</h3>
            <p>Start learning to see your progress here!</p>
          </div>
        )}
      </div>
    </div>
  )
}

// Courses Tab Component
const CoursesTab = ({ courses, onProgressUpdate, onReview }) => {
  return (
    <div className="courses-tab">
      <div className="tab-header">
        <h2>My Courses</h2>
        <p>Track your video course progress</p>
      </div>

      {courses.length > 0 ? (
        <div className="learning-grid">
          {courses.map((progress) => (
            <LearningCourseCard
              key={progress._id}
              progress={progress}
              onProgressUpdate={onProgressUpdate}
              onReview={onReview}
            />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <BookOpen size={64} />
          <h3>No courses enrolled yet</h3>
          <p>Browse our E-Learning section to find courses that interest you!</p>
        </div>
      )}
    </div>
  )
}

// Materials Tab Component
const MaterialsTab = ({ materials, onProgressUpdate, onReview }) => {
  return (
    <div className="materials-tab">
      <div className="tab-header">
        <h2>My Study Materials</h2>
        <p>Track your document and resource progress</p>
      </div>

      {materials.length > 0 ? (
        <div className="learning-grid">
          {materials.map((progress) => (
            <LearningMaterialCard
              key={progress._id}
              progress={progress}
              onProgressUpdate={onProgressUpdate}
              onReview={onReview}
            />
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <FileText size={64} />
          <h3>No materials accessed yet</h3>
          <p>Browse our Skills section to find study materials!</p>
        </div>
      )}
    </div>
  )
}

// Learning Course Card Component
const LearningCourseCard = ({ progress, onProgressUpdate, onReview }) => {
  const { course } = progress

  const handleProgressChange = (e) => {
    const newProgress = Number.parseInt(e.target.value)
    onProgressUpdate(progress._id, newProgress)
  }

  return (
    <div className="learning-card">
      <div className="card-header">
        <div className="course-thumbnail">
          {course.videoUrl ? (
            <div className="video-thumbnail">
              <Play size={32} />
            </div>
          ) : (
            <div className="no-video">
              <BookOpen size={32} />
            </div>
          )}
        </div>
        <div className="course-info">
          <h3>{course.title}</h3>
          <p className="mentor-name">by {course.mentor?.fullName}</p>
          <span className={`difficulty ${course.difficulty?.toLowerCase()}`}>{course.difficulty}</span>
        </div>
      </div>

      <div className="card-content">
        <p className="course-description">{course.description}</p>

        <div className="progress-section">
          <div className="progress-header">
            <span>Progress: {progress.progress}%</span>
            <span className={`status ${progress.status}`}>{progress.status}</span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress.progress}%` }}></div>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={progress.progress}
            onChange={handleProgressChange}
            className="progress-slider"
          />
        </div>

        <div className="learning-stats">
          <div className="stat">
            <Clock size={16} />
            <span>{progress.timeSpent || 0} min</span>
          </div>
          <div className="stat">
            <span>Last: {new Date(progress.lastAccessed).toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      <div className="card-actions">
        <button className="btn-primary">Continue Learning</button>
        {progress.status === "completed" && !progress.rating && (
          <button className="btn-secondary" onClick={() => onReview(progress)}>
            <Star size={16} />
            Rate & Review
          </button>
        )}
      </div>
    </div>
  )
}

// Learning Material Card Component
const LearningMaterialCard = ({ progress, onProgressUpdate, onReview }) => {
  const { material } = progress

  const handleProgressChange = (e) => {
    const newProgress = Number.parseInt(e.target.value)
    onProgressUpdate(progress._id, newProgress)
  }

  return (
    <div className="learning-card">
      <div className="card-header">
        <div className="material-icon">
          <FileText size={32} />
        </div>
        <div className="material-info">
          <h3>{material.title}</h3>
          <p className="material-type">{material.type}</p>
          <span className={`difficulty ${material.difficulty?.toLowerCase()}`}>{material.difficulty}</span>
        </div>
      </div>

      <div className="card-content">
        <p className="material-description">{material.description}</p>

        <div className="progress-section">
          <div className="progress-header">
            <span>Progress: {progress.progress}%</span>
            <span className={`status ${progress.status}`}>{progress.status}</span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${progress.progress}%` }}></div>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={progress.progress}
            onChange={handleProgressChange}
            className="progress-slider"
          />
        </div>

        <div className="learning-stats">
          <div className="stat">
            <Clock size={16} />
            <span>{progress.timeSpent || 0} min</span>
          </div>
          <div className="stat">
            <span>Last: {new Date(progress.lastAccessed).toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      <div className="card-actions">
        <button className="btn-primary">Open Material</button>
        {progress.status === "completed" && !progress.rating && (
          <button className="btn-secondary" onClick={() => onReview(progress)}>
            <Star size={16} />
            Rate & Review
          </button>
        )}
      </div>
    </div>
  )
}

// Review Modal Component
const ReviewModal = ({ item, onClose, onSubmit }) => {
  const [rating, setRating] = useState(5)
  const [review, setReview] = useState("")

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(rating, review)
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Rate & Review</h3>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="review-item">
          <h4>{item.course?.title || item.material?.title}</h4>
          <p>{item.course?.description || item.material?.description}</p>
        </div>

        <form onSubmit={handleSubmit} className="review-form">
          <div className="form-group">
            <label>Rating</label>
            <div className="star-rating">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  className={`star ${rating >= star ? "active" : ""}`}
                  onClick={() => setRating(star)}
                >
                  <Star size={24} />
                </button>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label>Review (Optional)</label>
            <textarea
              value={review}
              onChange={(e) => setReview(e.target.value)}
              placeholder="Share your thoughts about this learning experience..."
              rows={4}
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary">
              Submit Review
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default MyLearning
