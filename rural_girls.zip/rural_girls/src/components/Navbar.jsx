"use client"

import { useState, useEffect } from "react"
import { Bell, User, Menu, X } from "lucide-react"
import { getCurrentUser, getNotifications, getToken } from "../api.js"
import Profile from "./Profile.jsx"
import Notifications from "./Notifications.jsx"
import "./Navbar.css"

const Navbar = ({ activeSection, onSectionChange, onAuthClick }) => {
  const [user, setUser] = useState(null)
  const [showProfile, setShowProfile] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [notifications, setNotifications] = useState([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const currentUser = getCurrentUser()
    setUser(currentUser)
    if (currentUser) {
      fetchNotifications()
      // Set up notification polling
      const interval = setInterval(fetchNotifications, 30000) // Every 30 seconds
      return () => clearInterval(interval)
    }
  }, [])

  const fetchNotifications = async () => {
    try {
      const token = getToken()
      if (!token) return

      const response = await getNotifications(token)
      if (response.success) {
        setNotifications(response.notifications || [])
        const unread = response.notifications?.filter((n) => !n.isRead).length || 0
        setUnreadCount(unread)
      }
    } catch (error) {
      console.error("Failed to fetch notifications:", error)
    }
  }

  const handleProfileUpdate = (updatedUser) => {
    setUser(updatedUser)
  }

  const handleLogout = () => {
    setUser(null)
    setShowProfile(false)
    setNotifications([])
    setUnreadCount(0)
  }

  const navItems = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "elearning", label: "E-Learning", icon: "📚" },
    { id: "skills", label: "Skills", icon: "🎯" },
    { id: "community", label: "Community", icon: "👥" },
    ...(user?.role === "user" ? [{ id: "mentorship", label: "Mentorship", icon: "🤝" }] : []),
    { id: "marketplace", label: "Marketplace", icon: "🛒" },
    { id: "business", label: "Business", icon: "💼" },
  ]

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          {/* Logo */}
          <div className="navbar-logo">
            <div className="logo-icon">
              <img src="/placeholder.svg?height=40&width=40" alt="SheRise Logo" />
            </div>
            <span className="logo-text">SheRise</span>
          </div>

          {/* Desktop Navigation */}
          <div className="navbar-nav desktop-nav">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                className={`nav-item ${activeSection === item.id ? "active" : ""}`}
                onClick={() => onSectionChange(item.id)}
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            ))}
          </div>

          {/* User Actions */}
          <div className="navbar-actions">
            {user ? (
              <>
                {/* Notifications */}
                <div className="notification-wrapper">
                  <button
                    type="button"
                    className="notification-btn"
                    onClick={() => setShowNotifications(!showNotifications)}
                  >
                    <Bell size={20} />
                    {unreadCount > 0 && <span className="notification-badge">{unreadCount}</span>}
                  </button>
                  {showNotifications && (
                    <Notifications
                      notifications={notifications}
                      onClose={() => setShowNotifications(false)}
                      onRefresh={fetchNotifications}
                    />
                  )}
                </div>

                {/* Profile */}
                <button type="button" className="profile-btn" onClick={() => setShowProfile(true)}>
                  <User size={20} />
                  <span>{user.fullName}</span>
                </button>
              </>
            ) : (
              <button type="button" className="auth-btn" onClick={onAuthClick}>
                Join Free
              </button>
            )}

            {/* Mobile Menu Toggle */}
            <button type="button" className="mobile-menu-toggle" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="mobile-nav">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                className={`mobile-nav-item ${activeSection === item.id ? "active" : ""}`}
                onClick={() => {
                  onSectionChange(item.id)
                  setIsMobileMenuOpen(false)
                }}
              >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* Profile Modal */}
      {showProfile && user && (
        <Profile
          user={user}
          onClose={() => setShowProfile(false)}
          onLogout={handleLogout}
          onProfileUpdate={handleProfileUpdate}
        />
      )}
    </>
  )
}

export default Navbar
