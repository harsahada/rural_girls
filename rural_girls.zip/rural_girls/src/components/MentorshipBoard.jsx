"use client"

import { useState, useEffect } from "react"
import { Users, Briefcase, Send, User, Mail } from "lucide-react"
import { getMentors, sendConnectionRequest, getToken, getCurrentUser } from "../api.js"
import "./MentorshipBoard.css"

const MentorshipBoard = () => {
  const [mentors, setMentors] = useState([])
  const [loading, setLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState(null)
  const [showRequestModal, setShowRequestModal] = useState(false)
  const [selectedMentor, setSelectedMentor] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterIndustry, setFilterIndustry] = useState("All")

  useEffect(() => {
    const user = getCurrentUser()
    setCurrentUser(user)
    fetchMentors()
  }, [])

  const fetchMentors = async () => {
    try {
      setLoading(true)
      const token = getToken()
      const response = await getMentors(token)

      if (response.success) {
        setMentors(response.mentors || [])
      } else {
        console.error("Failed to fetch mentors:", response.message)
      }
    } catch (error) {
      console.error("Error fetching mentors:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleConnectRequest = (mentor) => {
    if (!currentUser) {
      alert("Please sign in to connect with mentors")
      return
    }

    if (currentUser.role === "mentor") {
      alert("Mentors cannot send connection requests to other mentors")
      return
    }

    setSelectedMentor(mentor)
    setShowRequestModal(true)
  }

  // Get unique industries for filter
  const industries = ["All", ...new Set(mentors.map((mentor) => mentor.industry).filter(Boolean))]

  // Filter mentors based on search and industry
  const filteredMentors = mentors.filter((mentor) => {
    const matchesSearch =
      mentor.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mentor.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mentor.goals?.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesIndustry = filterIndustry === "All" || mentor.industry === filterIndustry

    return matchesSearch && matchesIndustry
  })

  return (
    <div className="mentorship-board">
      {/* Hero Section */}
      <section className="board-hero">
        <div className="hero-content">
          <h1>Mentorship Board</h1>
          <p>Connect with experienced mentors who can guide your journey to success</p>
          <div className="hero-stats">
            <div className="stat">
              <h3>{mentors.length}</h3>
              <p>Expert Mentors</p>
            </div>
            <div className="stat">
              <h3>{industries.length - 1}</h3>
              <p>Industries</p>
            </div>
            <div className="stat">
              <h3>Free</h3>
              <p>Connections</p>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="board-filters">
        <div className="container">
          <div className="filters-row">
            <div className="search-box">
              <input
                type="text"
                placeholder="Search mentors by name, title, or expertise..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="filter-select">
              <select value={filterIndustry} onChange={(e) => setFilterIndustry(e.target.value)}>
                {industries.map((industry) => (
                  <option key={industry} value={industry}>
                    {industry}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Mentors Grid */}
      <section className="mentors-section">
        <div className="container">
          {loading ? (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Loading mentors...</p>
            </div>
          ) : filteredMentors.length > 0 ? (
            <div className="mentors-grid">
              {filteredMentors.map((mentor) => (
                <MentorCard
                  key={mentor._id}
                  mentor={mentor}
                  currentUser={currentUser}
                  onConnect={handleConnectRequest}
                />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <Users size={64} />
              <h3>No mentors found</h3>
              <p>
                {searchTerm || filterIndustry !== "All"
                  ? "Try adjusting your search filters"
                  : "No mentors have joined the platform yet. Check back soon!"}
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Connection Request Modal */}
      {showRequestModal && selectedMentor && (
        <ConnectionRequestModal
          mentor={selectedMentor}
          currentUser={currentUser}
          onClose={() => {
            setShowRequestModal(false)
            setSelectedMentor(null)
          }}
        />
      )}
    </div>
  )
}

// Enhanced Mentor Card Component
const MentorCard = ({ mentor, currentUser, onConnect }) => {
  return (
    <div className="mentor-card">
      <div className="mentor-header">
        <div className="mentor-avatar">
          {mentor.profilePicture ? (
            <img src={`http://localhost:5000/uploads/${mentor.profilePicture}`} alt={mentor.fullName} />
          ) : (
            <User size={32} />
          )}
        </div>
        <div className="mentor-info">
          <h3>{mentor.fullName}</h3>
          <p className="job-title">{mentor.jobTitle}</p>
          {mentor.industry && <span className="industry-tag">{mentor.industry}</span>}
        </div>
      </div>

      <div className="mentor-details">
        <div className="detail-item">
          <Briefcase size={16} />
          <span>{mentor.experience}</span>
        </div>
        {mentor.email && (
          <div className="detail-item">
            <Mail size={16} />
            <span>{mentor.email}</span>
          </div>
        )}
      </div>

      {mentor.goals && (
        <div className="mentor-bio">
          <h4>Mentoring Focus:</h4>
          <p>{mentor.goals}</p>
        </div>
      )}

      <div className="mentor-actions">
        <button
          className="connect-btn"
          onClick={() => onConnect(mentor)}
          disabled={!currentUser || currentUser.role === "mentor"}
        >
          <Send size={16} />
          Connect
        </button>
      </div>
    </div>
  )
}

// Enhanced Connection Request Modal Component
const ConnectionRequestModal = ({ mentor, currentUser, onClose }) => {
  const [formData, setFormData] = useState({
    message: "",
    requestType: "mentorship",
  })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const token = getToken()
      const response = await sendConnectionRequest(mentor._id, formData.message, formData.requestType, token)

      if (response.success) {
        alert("Connection request sent successfully! The mentor will be notified.")
        onClose()
      } else {
        alert(response.message || "Failed to send connection request")
      }
    } catch (error) {
      console.error("Error sending connection request:", error)
      alert("Failed to send connection request")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h3>Connect with {mentor.fullName}</h3>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <div className="mentor-preview">
          <div className="mentor-avatar">
            {mentor.profilePicture ? (
              <img src={`http://localhost:5000/uploads/${mentor.profilePicture}`} alt={mentor.fullName} />
            ) : (
              <User size={32} />
            )}
          </div>
          <div>
            <h4>{mentor.fullName}</h4>
            <p>{mentor.jobTitle}</p>
            <span className="industry-tag">{mentor.industry}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="connection-form">
          <div className="form-group">
            <label>Request Type</label>
            <select
              value={formData.requestType}
              onChange={(e) => setFormData({ ...formData, requestType: e.target.value })}
            >
              <option value="mentorship">Mentorship</option>
              <option value="collaboration">Collaboration</option>
              <option value="networking">Networking</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label>Personal Message</label>
            <textarea
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Introduce yourself and explain why you'd like to connect with this mentor..."
              rows={4}
              required
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Sending..." : "Send Request"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default MentorshipBoard
