"use client"

import { useState, useEffect } from "react"
import { FileText, Download, User, Eye, Heart, Search } from "lucide-react"
import { getPublicStudyMaterials, getCurrentUser } from "../api.js"
import "./Skills.css"

const Skills = () => {
  const [materials, setMaterials] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedType, setSelectedType] = useState("All")
  const [currentUser, setCurrentUser] = useState(null)

  const categories = [
    "All",
    "Business",
    "Arts & Crafts",
    "Agriculture",
    "Health & Wellness",
    "Communication Skills",
    "Digital Marketing",
    "Tailoring & Fashion",
    "Cooking & Food Processing",
    "Technology",
    "Education",
    "Other",
  ]

  const types = ["All", "PDF", "Document", "Presentation", "Spreadsheet"]

  useEffect(() => {
    const user = getCurrentUser()
    setCurrentUser(user)
    fetchMaterials()
  }, [])

  useEffect(() => {
    fetchMaterials()
  }, [selectedCategory, selectedType])

  const fetchMaterials = async () => {
    try {
      setLoading(true)
      const response = await getPublicStudyMaterials(
        1,
        selectedCategory === "All" ? null : selectedCategory,
        selectedType === "All" ? null : selectedType,
      )

      if (response.success) {
        setMaterials(response.materials || [])
      } else {
        console.error("Failed to fetch materials:", response.message)
      }
    } catch (error) {
      console.error("Error fetching materials:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredMaterials = materials.filter(
    (material) =>
      material.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      material.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="skills-page">
      {/* Hero Section */}
      <section className="skills-hero">
        <div className="hero-content">
          <h1>Skills Development Materials</h1>
          <p>Access study materials and resources shared by expert mentors</p>
          <div className="hero-stats">
            <div className="stat">
              <h3>{materials.length}</h3>
              <p>Study Materials</p>
            </div>
            <div className="stat">
              <h3>{categories.length - 1}</h3>
              <p>Categories</p>
            </div>
            <div className="stat">
              <h3>{types.length - 1}</h3>
              <p>File Types</p>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="search-filters">
        <div className="container">
          <div className="search-form">
            <div className="search-input">
              <Search size={20} />
              <input
                type="text"
                placeholder="Search materials..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="filters">
            <div className="filter-group">
              <label>Category:</label>
              <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label>Type:</label>
              <select value={selectedType} onChange={(e) => setSelectedType(e.target.value)}>
                {types.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Materials Grid */}
      <section className="materials-section">
        <div className="container">
          {loading ? (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Loading materials...</p>
            </div>
          ) : filteredMaterials.length > 0 ? (
            <div className="materials-grid">
              {filteredMaterials.map((material) => (
                <MaterialCard key={material._id} material={material} currentUser={currentUser} />
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <FileText size={64} />
              <h3>No materials found</h3>
              <p>
                {searchTerm || selectedCategory !== "All" || selectedType !== "All"
                  ? "Try adjusting your search filters"
                  : "No study materials have been uploaded yet. Check back soon!"}
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

// Material Card Component
const MaterialCard = ({ material, currentUser }) => {
  const handleDownload = () => {
    if (!currentUser) {
      alert("Please sign in to download materials")
      return
    }
    // TODO: Implement download logic
    alert("Download feature coming soon!")
  }

  const getFileIcon = (type) => {
    switch (type?.toLowerCase()) {
      case "pdf":
        return "📄"
      case "document":
        return "📝"
      case "presentation":
        return "📊"
      case "spreadsheet":
        return "📈"
      default:
        return "📁"
    }
  }

  return (
    <div className="material-card">
      <div className="material-header">
        <div className="file-icon">{getFileIcon(material.type)}</div>
        <div className="material-info">
          <h3>{material.title}</h3>
          <span className={`material-type ${material.type?.toLowerCase()}`}>{material.type}</span>
        </div>
      </div>

      <p className="material-description">{material.description}</p>

      <div className="material-meta">
        <div className="uploader-info">
          <User size={16} />
          <span>{material.uploadedBy?.fullName}</span>
          {material.uploadedBy?.jobTitle && <small>{material.uploadedBy.jobTitle}</small>}
        </div>

        <div className="material-details">
          <span className="category">{material.category}</span>
          <span className="difficulty">{material.difficulty}</span>
          <span className="language">{material.language}</span>
        </div>
      </div>

      {material.tags && material.tags.length > 0 && (
        <div className="material-tags">
          {material.tags.map((tag, index) => (
            <span key={index} className="tag">
              {tag}
            </span>
          ))}
        </div>
      )}

      <div className="material-stats">
        <div className="stat">
          <Eye size={16} />
          <span>{material.views || 0} views</span>
        </div>
        <div className="stat">
          <Heart size={16} />
          <span>{material.likes?.length || 0} likes</span>
        </div>
      </div>

      <div className="material-actions">
        <button className="btn-primary" onClick={handleDownload}>
          <Download size={16} />
          Download
        </button>
      </div>
    </div>
  )
}

export default Skills
