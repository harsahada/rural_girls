/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}", // important to scan React files
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#a5b4fc', // pastel blue
          light: '#dbeafe',   // lighter blue
          dark: '#6366f1',    // deeper blue
          bg: '#f3f4f6',      // soft gray background
          accent: '#fbcfe8',  // pastel pink accent
          mint: '#bbf7d0',    // pastel mint
          lavender: '#e9d5ff',// pastel lavender
        },
      },
      boxShadow: {
        'pastel-glow': '0 4px 24px 0 rgba(165,180,252,0.18)',
      },
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
      },
      transitionProperty: {
        'colorscale': 'background, color, box-shadow, transform',
      },
    },
  },
  plugins: [require('@tailwindcss/forms')],
}
