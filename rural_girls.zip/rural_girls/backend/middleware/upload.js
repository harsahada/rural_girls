import multer from "multer"
import path from "path"
import fs from "fs"

// Create uploads directory if it doesn't exist
const uploadsDir = "uploads"
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir)
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname))
  },
})

// File filter function
const fileFilter = (req, file, cb) => {
  console.log("📁 File upload attempt:", file.originalname, "Type:", file.mimetype)

  // Define allowed file types based on the route
  const allowedTypes = {
    // E-Learning courses - videos only
    courseVideo: /\.(mp4|avi|mov|wmv|flv)$/i,

    // Skills materials - documents only
    materialFile: /\.(pdf|doc|docx|ppt|pptx|xls|xlsx)$/i,

    // Community forum - images and documents
    attachments: /\.(jpg|jpeg|png|gif|bmp|webp|pdf|doc|docx|ppt|pptx)$/i,
  }

  const fieldName = file.fieldname
  const fileName = file.originalname.toLowerCase()

  if (allowedTypes[fieldName]) {
    if (allowedTypes[fieldName].test(fileName)) {
      cb(null, true)
    } else {
      cb(new Error(`Invalid file type for ${fieldName}. Please check allowed file types.`), false)
    }
  } else {
    // Default - allow common file types
    if (/\.(jpg|jpeg|png|gif|pdf|doc|docx|ppt|pptx|mp4|avi|mov)$/i.test(fileName)) {
      cb(null, true)
    } else {
      cb(new Error("File type not allowed"), false)
    }
  }
}

// Configure multer
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
})

export default upload
