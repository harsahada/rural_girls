import jwt from "jsonwebtoken"
import User from "../models/User.js"

export const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers["authorization"]
    const token = authHeader && authHeader.split(" ")[1]

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Access token required",
      })
    }

    // Verify the token
    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    // Get user from database to ensure they still exist and get latest role
    const user = await User.findById(decoded.userId).select("-password")

    if (!user) {
      return res.status(401).json({
        success: false,
        message: "User not found",
      })
    }

    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: "Account is deactivated",
      })
    }

    // Attach user info to request
    req.user = {
      userId: user._id,
      email: user.email,
      role: user.role,
      fullName: user.fullName,
      isApproved: user.isApproved,
    }

    next()
  } catch (error) {
    console.error("❌ Authentication error:", error)

    if (error.name === "JsonWebTokenError") {
      return res.status(403).json({
        success: false,
        message: "Invalid token",
      })
    }

    if (error.name === "TokenExpiredError") {
      return res.status(403).json({
        success: false,
        message: "Token expired",
      })
    }

    return res.status(500).json({
      success: false,
      message: "Authentication failed",
    })
  }
}

// Middleware to check if user is a mentor
export const requireMentor = (req, res, next) => {
  if (req.user.role !== "mentor") {
    return res.status(403).json({
      success: false,
      message: "Access denied. Mentor role required.",
    })
  }

  if (!req.user.isApproved) {
    return res.status(403).json({
      success: false,
      message: "Access denied. Mentor account pending approval.",
    })
  }

  next()
}

// Middleware to check if user is a regular user
export const requireUser = (req, res, next) => {
  if (req.user.role !== "user") {
    return res.status(403).json({
      success: false,
      message: "Access denied. User role required.",
    })
  }

  next()
}
