import express from "express"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import User from "../models/User.js"
import { authenticateToken } from "../middleware/auth.js"
import upload from "../middleware/upload.js"

const router = express.Router()

// 👤 USER SIGNUP
router.post("/signup/user", async (req, res) => {
  try {
    const { fullName, email, password, state, age, language, interests } = req.body

    console.log("👤 User signup attempt:", email)

    // Check if user already exists
    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "User with this email already exists",
      })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const user = new User({
      fullName,
      email,
      password: hashedPassword,
      role: "user",
      state,
      age: Number.parseInt(age),
      language: language || "English",
      interests: Array.isArray(interests) ? interests : interests?.split(",").map((i) => i.trim()) || [],
    })

    await user.save()

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email,
        role: user.role,
        fullName: user.fullName,
      },
      process.env.JWT_SECRET || "your-secret-key",
      { expiresIn: "7d" },
    )

    console.log("✅ User created successfully:", user.email)

    res.status(201).json({
      success: true,
      message: "User account created successfully!",
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("❌ User signup error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create user account",
      error: error.message,
    })
  }
})

// 👨‍🏫 MENTOR SIGNUP
router.post("/signup/mentor", async (req, res) => {
  try {
    const { fullName, email, password, phone, jobTitle, experience, industry, goals } = req.body

    console.log("👨‍🏫 Mentor signup attempt:", email)

    // Check if user already exists
    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "User with this email already exists",
      })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create mentor
    const mentor = new User({
      fullName,
      email,
      password: hashedPassword,
      role: "mentor",
      phone,
      jobTitle,
      experience,
      industry,
      goals,
      isApproved: false, // Mentors need approval
    })

    await mentor.save()

    console.log("✅ Mentor created successfully (pending approval):", mentor.email)

    res.status(201).json({
      success: true,
      message: "Mentor account created successfully! Please wait for approval.",
      mentor: {
        id: mentor._id,
        fullName: mentor.fullName,
        email: mentor.email,
        role: mentor.role,
        isApproved: mentor.isApproved,
      },
    })
  } catch (error) {
    console.error("❌ Mentor signup error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to create mentor account",
      error: error.message,
    })
  }
})

// 🔐 SIGNIN
router.post("/signin", async (req, res) => {
  try {
    const { email, password } = req.body

    console.log("🔐 Signin attempt:", email)

    // Find user
    const user = await User.findOne({ email })
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      })
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password)
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      })
    }

    // Check if mentor is approved
    if (user.role === "mentor" && !user.isApproved) {
      return res.status(403).json({
        success: false,
        message: "Your mentor account is pending approval. Please wait for admin approval.",
      })
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email,
        role: user.role,
        fullName: user.fullName,
      },
      process.env.JWT_SECRET || "your-secret-key",
      { expiresIn: "7d" },
    )

    console.log("✅ User signed in successfully:", user.email)

    res.json({
      success: true,
      message: "Signed in successfully!",
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("❌ Signin error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to sign in",
      error: error.message,
    })
  }
})

// 👤 GET USER PROFILE
router.get("/profile", authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select("-password")

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    res.json({
      success: true,
      user,
    })
  } catch (error) {
    console.error("❌ Get profile error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch profile",
      error: error.message,
    })
  }
})

// ✏️ UPDATE USER PROFILE
router.post("/profile", authenticateToken, upload.single("profilePicture"), async (req, res) => {
  try {
    const userId = req.user.userId
    const updateData = { ...req.body }

    // Handle interests array
    if (updateData.interests && typeof updateData.interests === "string") {
      try {
        updateData.interests = JSON.parse(updateData.interests)
      } catch {
        updateData.interests = updateData.interests.split(",").map((item) => item.trim())
      }
    }

    // Handle profile picture upload
    if (req.file) {
      updateData.profilePicture = req.file.filename
    }

    // Remove fields that shouldn't be updated
    delete updateData.email
    delete updateData.password
    delete updateData.role
    delete updateData._id
    delete updateData.profilePicturePreview

    const user = await User.findByIdAndUpdate(userId, updateData, {
      new: true,
      runValidators: true,
    }).select("-password")

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    console.log("✅ Profile updated successfully:", user.email)

    res.json({
      success: true,
      message: "Profile updated successfully!",
      user,
    })
  } catch (error) {
    console.error("❌ Update profile error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to update profile",
      error: error.message,
    })
  }
})

// 🔒 CHANGE PASSWORD
router.put("/change-password", authenticateToken, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body
    const userId = req.user.userId

    // Find user
    const user = await User.findById(userId)
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      })
    }

    // Verify current password
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password)
    if (!isCurrentPasswordValid) {
      return res.status(400).json({
        success: false,
        message: "Current password is incorrect",
      })
    }

    // Hash new password
    const hashedNewPassword = await bcrypt.hash(newPassword, 12)

    // Update password
    await User.findByIdAndUpdate(userId, { password: hashedNewPassword })

    console.log("✅ Password changed successfully for:", user.email)

    res.json({
      success: true,
      message: "Password changed successfully!",
    })
  } catch (error) {
    console.error("❌ Change password error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to change password",
      error: error.message,
    })
  }
})

export default router
