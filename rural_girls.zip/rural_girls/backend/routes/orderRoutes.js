import express from 'express';
const router = express.Router();

// Sample route
router.get('/', (req, res) => {
  res.json({ message: 'Order route working!' });
});

export default router;
