import express from "express"
import Post from "../models/Post.js"
import { authenticateToken } from "../middleware/auth.js"
import upload from "../middleware/upload.js"

const router = express.Router()

// 📋 GET ALL PUBLIC FORUM POSTS (Visible to everyone)
router.get("/posts", async (req, res) => {
  try {
    const { page = 1, limit = 10, category } = req.query

    // Build filter
    const filter = { isPublished: true }
    if (category && category !== "All") {
      filter.category = category
    }

    // Calculate pagination
    const skip = (page - 1) * limit

    // Get posts with author info
    const posts = await Post.find(filter)
      .populate("author", "fullName role jobTitle")
      .populate("comments.author", "fullName role")
      .sort({ isPinned: -1, createdAt: -1 })
      .skip(skip)
      .limit(Number(limit))

    // Get total count
    const total = await Post.countDocuments(filter)

    res.json({
      success: true,
      posts,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("❌ Get forum posts error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch forum posts",
      error: error.message,
    })
  }
})

// 📝 CREATE FORUM POST (Authenticated users)
router.post("/posts", authenticateToken, upload.array("attachments", 5), async (req, res) => {
  try {
    const { title, content, category, tags, isPinned } = req.body

    const postData = {
      title,
      content,
      category,
      tags: tags ? tags.split(",").map((tag) => tag.trim()) : [],
      author: req.user.userId,
      authorRole: req.user.role,
      isPinned: req.user.role === "mentor" && isPinned === "true",
    }

    // Add attachments if uploaded
    if (req.files && req.files.length > 0) {
      postData.attachments = req.files.map((file) => ({
        name: file.originalname,
        fileUrl: file.filename,
        fileType: file.mimetype.split("/")[0],
      }))
    }

    const post = new Post(postData)
    await post.save()

    // Populate author info for response
    await post.populate("author", "fullName role jobTitle")

    res.status(201).json({
      success: true,
      message: "Post created successfully!",
      post,
    })
  } catch (error) {
    console.error("❌ Create post error:", error)
    res.status(400).json({
      success: false,
      message: "Failed to create post",
      error: error.message,
    })
  }
})

// 👍 LIKE/UNLIKE POST
router.post("/posts/:postId/like", authenticateToken, async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId)
    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    const userId = req.user.userId
    const likeIndex = post.likes.indexOf(userId)

    if (likeIndex > -1) {
      // Unlike
      post.likes.splice(likeIndex, 1)
    } else {
      // Like
      post.likes.push(userId)
    }

    await post.save()

    res.json({
      success: true,
      message: likeIndex > -1 ? "Post unliked" : "Post liked",
      likesCount: post.likes.length,
    })
  } catch (error) {
    console.error("❌ Like post error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to like post",
      error: error.message,
    })
  }
})

// 💬 ADD COMMENT TO POST
router.post("/posts/:postId/comments", authenticateToken, async (req, res) => {
  try {
    const { content } = req.body
    const post = await Post.findById(req.params.postId)

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      })
    }

    const comment = {
      author: req.user.userId,
      content,
      createdAt: new Date(),
    }

    post.comments.push(comment)
    await post.save()

    // Populate the new comment
    await post.populate("comments.author", "fullName role")

    res.status(201).json({
      success: true,
      message: "Comment added successfully!",
      comment: post.comments[post.comments.length - 1],
    })
  } catch (error) {
    console.error("❌ Add comment error:", error)
    res.status(400).json({
      success: false,
      message: "Failed to add comment",
      error: error.message,
    })
  }
})

export default router
