import express from "express"
import LearningProgress from "../models/LearningProgress.js"
import Course from "../models/Course.js"
import StudyMaterial from "../models/StudyMaterial.js"
import { authenticateToken } from "../middleware/auth.js"
import { createNotification } from "./notificationRoutes.js"

const router = express.Router()

// 📚 ENROLL IN COURSE
router.post("/enroll/:courseId", authenticateToken, async (req, res) => {
  try {
    const { courseId } = req.params
    const userId = req.user.userId

    // Check if course exists
    const course = await Course.findById(courseId).populate("mentor", "fullName")
    if (!course) {
      return res.status(404).json({
        success: false,
        message: "Course not found",
      })
    }

    // Check if already enrolled
    const existingProgress = await LearningProgress.findOne({
      user: userId,
      course: courseId,
      type: "course",
    })

    if (existingProgress) {
      return res.status(400).json({
        success: false,
        message: "Already enrolled in this course",
      })
    }

    // Create learning progress record
    const progress = new LearningProgress({
      user: userId,
      course: courseId,
      type: "course",
      status: "enrolled",
    })

    await progress.save()

    // Add user to course enrolled users
    await Course.findByIdAndUpdate(courseId, {
      $addToSet: { enrolledUsers: { user: userId } },
    })

    // Create notification for mentor
    await createNotification(
      course.mentor._id,
      userId,
      "course_enrollment",
      "New Course Enrollment! 🎉",
      `${req.user.fullName} has enrolled in your course "${course.title}"`,
      {
        courseId: course._id,
        courseName: course.title,
      },
    )

    res.status(201).json({
      success: true,
      message: "Successfully enrolled in course!",
      progress,
    })
  } catch (error) {
    console.error("❌ Course enrollment error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to enroll in course",
      error: error.message,
    })
  }
})

// 📖 ACCESS STUDY MATERIAL
router.post("/access-material/:materialId", authenticateToken, async (req, res) => {
  try {
    const { materialId } = req.params
    const userId = req.user.userId

    // Check if material exists
    const material = await StudyMaterial.findById(materialId)
    if (!material) {
      return res.status(404).json({
        success: false,
        message: "Study material not found",
      })
    }

    // Find or create learning progress record
    let progress = await LearningProgress.findOne({
      user: userId,
      material: materialId,
      type: "material",
    })

    if (!progress) {
      progress = new LearningProgress({
        user: userId,
        material: materialId,
        type: "material",
        status: "in_progress",
      })
    } else {
      progress.lastAccessed = new Date()
      if (progress.status === "enrolled") {
        progress.status = "in_progress"
      }
    }

    await progress.save()

    res.json({
      success: true,
      message: "Material access recorded",
      progress,
    })
  } catch (error) {
    console.error("❌ Material access error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to record material access",
      error: error.message,
    })
  }
})

// 📊 UPDATE PROGRESS
router.put("/progress/:progressId", authenticateToken, async (req, res) => {
  try {
    const { progressId } = req.params
    const { progress: progressValue, timeSpent, status, notes } = req.body
    const userId = req.user.userId

    const learningProgress = await LearningProgress.findOne({
      _id: progressId,
      user: userId,
    })

    if (!learningProgress) {
      return res.status(404).json({
        success: false,
        message: "Learning progress not found",
      })
    }

    // Update progress
    if (progressValue !== undefined) {
      learningProgress.progress = Math.min(100, Math.max(0, progressValue))
    }

    if (timeSpent !== undefined) {
      learningProgress.timeSpent += timeSpent
    }

    if (status) {
      learningProgress.status = status
    }

    if (notes) {
      learningProgress.notes = notes
    }

    learningProgress.lastAccessed = new Date()

    // Mark as completed if progress is 100%
    if (learningProgress.progress >= 100 && learningProgress.status !== "completed") {
      learningProgress.status = "completed"
      learningProgress.completedAt = new Date()
    }

    await learningProgress.save()

    res.json({
      success: true,
      message: "Progress updated successfully",
      progress: learningProgress,
    })
  } catch (error) {
    console.error("❌ Update progress error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to update progress",
      error: error.message,
    })
  }
})

// 📋 GET USER'S LEARNING PROGRESS
router.get("/my-learning", authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId
    const { type, status } = req.query

    const filter = { user: userId }
    if (type) filter.type = type
    if (status) filter.status = status

    const progress = await LearningProgress.find(filter)
      .populate("course", "title description category difficulty mentor videoUrl")
      .populate("material", "title description category type fileUrl fileName")
      .populate({
        path: "course",
        populate: {
          path: "mentor",
          select: "fullName jobTitle",
        },
      })
      .sort({ lastAccessed: -1 })

    // Separate courses and materials
    const courses = progress.filter((p) => p.type === "course")
    const materials = progress.filter((p) => p.type === "material")

    // Calculate statistics
    const stats = {
      totalCourses: courses.length,
      completedCourses: courses.filter((c) => c.status === "completed").length,
      inProgressCourses: courses.filter((c) => c.status === "in_progress").length,
      totalMaterials: materials.length,
      completedMaterials: materials.filter((m) => m.status === "completed").length,
      totalTimeSpent: progress.reduce((sum, p) => sum + (p.timeSpent || 0), 0),
    }

    res.json({
      success: true,
      data: {
        courses,
        materials,
        stats,
      },
    })
  } catch (error) {
    console.error("❌ Get learning progress error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch learning progress",
      error: error.message,
    })
  }
})

// ⭐ RATE AND REVIEW
router.post("/review/:progressId", authenticateToken, async (req, res) => {
  try {
    const { progressId } = req.params
    const { rating, review } = req.body
    const userId = req.user.userId

    const learningProgress = await LearningProgress.findOne({
      _id: progressId,
      user: userId,
    })

    if (!learningProgress) {
      return res.status(404).json({
        success: false,
        message: "Learning progress not found",
      })
    }

    learningProgress.rating = rating
    learningProgress.review = review
    await learningProgress.save()

    res.json({
      success: true,
      message: "Review submitted successfully",
      progress: learningProgress,
    })
  } catch (error) {
    console.error("❌ Submit review error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to submit review",
      error: error.message,
    })
  }
})

export default router
