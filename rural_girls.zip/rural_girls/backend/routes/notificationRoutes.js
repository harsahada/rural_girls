import express from "express"
import Notification from "../models/Notification.js"
import { authenticateToken } from "../middleware/auth.js"

const router = express.Router()

// Helper function to create notifications
export const createNotification = async (recipientId, senderId, type, title, message, data = {}) => {
  try {
    const notification = new Notification({
      recipient: recipientId,
      sender: senderId,
      type,
      title,
      message,
      data,
    })

    await notification.save()
    console.log(`✅ Notification created: ${type} for user ${recipientId}`)
    return notification
  } catch (error) {
    console.error("❌ Failed to create notification:", error)
    throw error
  }
}

// 📋 GET USER NOTIFICATIONS
router.get("/", authenticateToken, async (req, res) => {
  try {
    const notifications = await Notification.find({ recipient: req.user.userId })
      .populate("sender", "fullName profilePicture")
      .sort({ createdAt: -1 })
      .limit(50)

    res.json({
      success: true,
      notifications,
    })
  } catch (error) {
    console.error("❌ Get notifications error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch notifications",
      error: error.message,
    })
  }
})

// ✅ MARK NOTIFICATION AS READ
router.put("/:notificationId/read", authenticateToken, async (req, res) => {
  try {
    const { notificationId } = req.params

    const notification = await Notification.findOneAndUpdate(
      { _id: notificationId, recipient: req.user.userId },
      { isRead: true },
      { new: true },
    )

    if (!notification) {
      return res.status(404).json({
        success: false,
        message: "Notification not found",
      })
    }

    res.json({
      success: true,
      notification,
    })
  } catch (error) {
    console.error("❌ Mark notification as read error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to mark notification as read",
      error: error.message,
    })
  }
})

// ✅ MARK ALL NOTIFICATIONS AS READ
router.put("/mark-all-read", authenticateToken, async (req, res) => {
  try {
    await Notification.updateMany({ recipient: req.user.userId, isRead: false }, { isRead: true })

    res.json({
      success: true,
      message: "All notifications marked as read",
    })
  } catch (error) {
    console.error("❌ Mark all notifications as read error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to mark all notifications as read",
      error: error.message,
    })
  }
})

export default router
