import express from "express"
import Course from "../models/Course.js"
import StudyMaterial from "../models/StudyMaterial.js"

const router = express.Router()

// 📚 GET ALL PUBLIC COURSES (Visible to everyone)
router.get("/", async (req, res) => {
  try {
    const { page = 1, limit = 12, category, difficulty, search } = req.query

    // Build filter
    const filter = { isPublished: true }

    if (category && category !== "All") {
      filter.category = category
    }

    if (difficulty && difficulty !== "All") {
      filter.difficulty = difficulty
    }

    if (search) {
      filter.$or = [{ title: { $regex: search, $options: "i" } }, { description: { $regex: search, $options: "i" } }]
    }

    // Calculate pagination
    const skip = (page - 1) * limit

    // Get courses with mentor info
    const courses = await Course.find(filter)
      .populate("mentor", "fullName jobTitle")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit))

    // Get total count
    const total = await Course.countDocuments(filter)

    res.json({
      success: true,
      courses,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("❌ Get courses error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch courses",
      error: error.message,
    })
  }
})

// 📖 GET SINGLE COURSE
router.get("/:courseId", async (req, res) => {
  try {
    const course = await Course.findById(req.params.courseId)
      .populate("mentor", "fullName jobTitle experience")
      .populate("enrolledUsers.user", "fullName")

    if (!course) {
      return res.status(404).json({
        success: false,
        message: "Course not found",
      })
    }

    // Increment view count
    course.views += 1
    await course.save()

    res.json({
      success: true,
      course,
    })
  } catch (error) {
    console.error("❌ Get course error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch course",
      error: error.message,
    })
  }
})

// 📚 GET ALL PUBLIC STUDY MATERIALS
router.get("/materials/public", async (req, res) => {
  try {
    const { page = 1, limit = 12, category, type } = req.query

    // Build filter
    const filter = { isPublic: true }

    if (category && category !== "All") {
      filter.category = category
    }

    if (type && type !== "All") {
      filter.type = type
    }

    // Calculate pagination
    const skip = (page - 1) * limit

    // Get materials with uploader info
    const materials = await StudyMaterial.find(filter)
      .populate("uploadedBy", "fullName role jobTitle")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit))

    // Get total count
    const total = await StudyMaterial.countDocuments(filter)

    res.json({
      success: true,
      materials,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("❌ Get study materials error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch study materials",
      error: error.message,
    })
  }
})

export default router
