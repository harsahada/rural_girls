import express from "express"
import { authenticateToken, requireMentor } from "../middleware/auth.js"
import Course from "../models/Course.js"
import StudyMaterial from "../models/StudyMaterial.js"
import Post from "../models/Post.js"
import ConnectionRequest from "../models/ConnectionRequest.js"
import upload from "../middleware/upload.js"
import { createNotification } from "./notificationRoutes.js"
import User from "../models/User.js"

const router = express.Router()

// Apply mentor authentication to all routes
router.use(authenticateToken)
router.use(requireMentor)

// 📊 MENTOR DASHBOARD
router.get("/dashboard", async (req, res) => {
  try {
    const mentorId = req.user.userId

    console.log("📊 Loading dashboard for mentor:", mentorId)

    // Get dashboard statistics
    const [totalCourses, totalPosts, totalMaterials, pendingRequests] = await Promise.all([
      Course.countDocuments({ mentor: mentorId }),
      Post.countDocuments({ author: mentorId }),
      StudyMaterial.countDocuments({ uploadedBy: mentorId }),
      ConnectionRequest.countDocuments({ to: mentorId, status: "pending" }),
    ])

    const publishedCourses = await Course.countDocuments({ mentor: mentorId, isPublished: true })

    // Get total views and enrollments
    const courses = await Course.find({ mentor: mentorId })
    const totalViews = courses.reduce((sum, course) => sum + (course.views || 0), 0)
    const totalEnrollments = courses.reduce((sum, course) => sum + (course.enrolledUsers?.length || 0), 0)

    // Get recent activity
    const [recentCourses, recentRequests] = await Promise.all([
      Course.find({ mentor: mentorId }).sort({ createdAt: -1 }).limit(5),
      ConnectionRequest.find({ to: mentorId }).sort({ createdAt: -1 }).limit(5),
    ])

    const dashboardData = {
      overview: {
        totalCourses: totalCourses || 0,
        publishedCourses: publishedCourses || 0,
        totalPosts: totalPosts || 0,
        totalMaterials: totalMaterials || 0,
        pendingRequests: pendingRequests || 0,
        totalViews: totalViews || 0,
        totalEnrollments: totalEnrollments || 0,
      },
      recentActivity: {
        recentCourses: recentCourses || [],
        recentRequests: recentRequests || [],
      },
    }

    console.log("✅ Dashboard data loaded successfully")

    res.json({
      success: true,
      data: dashboardData,
    })
  } catch (error) {
    console.error("❌ Dashboard error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to load dashboard",
      error: error.message,
    })
  }
})

// 📚 GET MENTOR COURSES
router.get("/courses", async (req, res) => {
  try {
    const courses = await Course.find({ mentor: req.user.userId })
      .populate("enrolledUsers.user", "fullName")
      .sort({ createdAt: -1 })

    res.json({
      success: true,
      courses,
    })
  } catch (error) {
    console.error("❌ Get courses error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch courses",
      error: error.message,
    })
  }
})

// 📚 CREATE COURSE
router.post("/courses", upload.single("courseVideo"), async (req, res) => {
  try {
    const { title, description, category, difficulty, duration, language } = req.body

    const courseData = {
      title,
      description,
      category,
      difficulty,
      duration,
      language,
      mentor: req.user.userId,
      isPublished: true, // Auto-publish for now
    }

    if (req.file) {
      courseData.videoUrl = req.file.filename
    }

    const course = new Course(courseData)
    await course.save()

    await course.populate("mentor", "fullName jobTitle")

    res.status(201).json({
      success: true,
      message: "Course created successfully!",
      course,
    })
  } catch (error) {
    console.error("❌ Create course error:", error)
    res.status(400).json({
      success: false,
      message: "Failed to create course",
      error: error.message,
    })
  }
})

// 📄 GET MENTOR STUDY MATERIALS
router.get("/materials", async (req, res) => {
  try {
    const materials = await StudyMaterial.find({ uploadedBy: req.user.userId }).sort({ createdAt: -1 })

    res.json({
      success: true,
      materials,
    })
  } catch (error) {
    console.error("❌ Get materials error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch materials",
      error: error.message,
    })
  }
})

// 📄 UPLOAD STUDY MATERIAL
router.post("/materials", upload.single("materialFile"), async (req, res) => {
  try {
    const { title, description, category, type, difficulty, language, tags, isPublic } = req.body

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Material file is required",
      })
    }

    const material = new StudyMaterial({
      title,
      description,
      category,
      type,
      difficulty,
      language,
      tags: tags ? tags.split(",").map((tag) => tag.trim()) : [],
      isPublic: isPublic === "true",
      fileUrl: req.file.filename,
      fileName: req.file.originalname,
      fileSize: req.file.size,
      uploadedBy: req.user.userId,
    })

    await material.save()
    await material.populate("uploadedBy", "fullName role")

    res.status(201).json({
      success: true,
      message: "Study material uploaded successfully!",
      material,
    })
  } catch (error) {
    console.error("❌ Upload material error:", error)
    res.status(400).json({
      success: false,
      message: "Failed to upload material",
      error: error.message,
    })
  }
})

// 💬 GET MENTOR POSTS
router.get("/posts", async (req, res) => {
  try {
    const posts = await Post.find({ author: req.user.userId })
      .populate("comments.author", "fullName role")
      .sort({ createdAt: -1 })

    res.json({
      success: true,
      posts,
    })
  } catch (error) {
    console.error("❌ Get posts error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch posts",
      error: error.message,
    })
  }
})

// 📨 GET CONNECTION REQUESTS
router.get("/connection-requests", async (req, res) => {
  try {
    const requests = await ConnectionRequest.find({ to: req.user.userId })
      .populate("from", "fullName email role")
      .sort({ createdAt: -1 })

    res.json({
      success: true,
      requests,
    })
  } catch (error) {
    console.error("❌ Get connection requests error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch connection requests",
      error: error.message,
    })
  }
})

// 📨 RESPOND TO CONNECTION REQUEST
router.put("/connection-requests/:requestId", async (req, res) => {
  try {
    const { requestId } = req.params
    const { status, responseMessage } = req.body

    if (!["accepted", "rejected"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status. Must be 'accepted' or 'rejected'",
      })
    }

    const request = await ConnectionRequest.findOne({
      _id: requestId,
      to: req.user.userId,
    }).populate("from", "fullName email")

    if (!request) {
      return res.status(404).json({
        success: false,
        message: "Connection request not found",
      })
    }

    if (request.status !== "pending") {
      return res.status(400).json({
        success: false,
        message: "Request has already been processed",
      })
    }

    request.status = status
    request.responseMessage = responseMessage || ""
    request.respondedAt = new Date()

    await request.save()

    // Get mentor info for notification
    const mentor = await User.findById(req.user.userId).select("fullName phone")

    // Create notification for user
    if (status === "accepted") {
      await createNotification(
        request.from._id,
        req.user.userId,
        "connection_accepted",
        "Connection Request Accepted! 🎉",
        `${mentor.fullName} has accepted your connection request. You can now contact them at ${mentor.phone}`,
        {
          mentorPhone: mentor.phone,
          mentorName: mentor.fullName,
          responseMessage,
        },
      )
    } else {
      await createNotification(
        request.from._id,
        req.user.userId,
        "connection_rejected",
        "Connection Request Update",
        `${mentor.fullName} has declined your connection request. ${responseMessage || "Keep exploring other mentors!"}`,
        {
          mentorName: mentor.fullName,
          responseMessage,
        },
      )
    }

    res.json({
      success: true,
      message: `Connection request ${status} successfully!`,
      request,
    })
  } catch (error) {
    console.error("❌ Respond to connection request error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to respond to connection request",
      error: error.message,
    })
  }
})

export default router
