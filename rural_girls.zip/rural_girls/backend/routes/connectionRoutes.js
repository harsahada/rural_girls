import express from "express"
import ConnectionRequest from "../models/ConnectionRequest.js"
import User from "../models/User.js"
import { authenticateToken } from "../middleware/auth.js"
import { createNotification } from "./notificationRoutes.js"

const router = express.Router()

// 📨 SEND CONNECTION REQUEST (Users to Mentors)
router.post("/send", authenticateToken, async (req, res) => {
  try {
    const { mentorId, message, requestType } = req.body

    console.log("🔍 Looking for mentor with ID:", mentorId)

    // Check if mentor exists and is approved
    const mentor = await User.findOne({
      _id: mentorId,
      role: "mentor",
      isActive: true,
      isApproved: true,
    })

    if (!mentor) {
      console.log("❌ Mentor not found or not approved")
      return res.status(404).json({
        success: false,
        message: "Mentor not found or not available",
      })
    }

    console.log("✅ Found mentor:", mentor.fullName)

    // Check if request already exists
    const existingRequest = await ConnectionRequest.findOne({
      from: req.user.userId,
      to: mentorId,
    })

    if (existingRequest) {
      return res.status(400).json({
        success: false,
        message: "Connection request already sent to this mentor",
      })
    }

    // Create new connection request
    const connectionRequest = new ConnectionRequest({
      from: req.user.userId,
      to: mentorId,
      message: message || "",
      requestType: requestType || "mentorship",
    })

    await connectionRequest.save()

    // Populate user info for response
    await connectionRequest.populate("from", "fullName email role")

    // Create notification for mentor
    await createNotification(
      mentorId,
      req.user.userId,
      "connection_request",
      "New Connection Request",
      `${req.user.fullName} wants to connect with you for ${requestType}`,
      {
        requestId: connectionRequest._id,
        requestType,
        userMessage: message,
      },
    )

    console.log("✅ Connection request created successfully")

    res.status(201).json({
      success: true,
      message: "Connection request sent successfully!",
      request: connectionRequest,
    })
  } catch (error) {
    console.error("❌ Send connection request error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to send connection request",
      error: error.message,
    })
  }
})

// 📋 GET ALL MENTORS (For users to browse)
router.get("/mentors", authenticateToken, async (req, res) => {
  try {
    const mentors = await User.find({
      role: "mentor",
      isActive: true,
      isApproved: true,
    }).select("fullName email jobTitle experience industry goals phone")

    res.json({
      success: true,
      mentors,
    })
  } catch (error) {
    console.error("❌ Get mentors error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch mentors",
      error: error.message,
    })
  }
})

// 📨 GET USER'S SENT REQUESTS
router.get("/sent", authenticateToken, async (req, res) => {
  try {
    const requests = await ConnectionRequest.find({ from: req.user.userId })
      .populate("to", "fullName email jobTitle")
      .sort({ createdAt: -1 })

    res.json({
      success: true,
      requests,
    })
  } catch (error) {
    console.error("❌ Get sent requests error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch sent requests",
      error: error.message,
    })
  }
})

export default router
