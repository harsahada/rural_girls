import mongoose from "mongoose"

const learningProgressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  course: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Course",
  },
  material: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "StudyMaterial",
  },
  type: {
    type: String,
    enum: ["course", "material"],
    required: true,
  },
  status: {
    type: String,
    enum: ["enrolled", "in_progress", "completed", "paused"],
    default: "enrolled",
  },
  progress: {
    type: Number,
    default: 0,
    min: 0,
    max: 100,
  },
  timeSpent: {
    type: Number, // in minutes
    default: 0,
  },
  lastAccessed: {
    type: Date,
    default: Date.now,
  },
  completedAt: {
    type: Date,
  },
  enrolledAt: {
    type: Date,
    default: Date.now,
  },
  notes: {
    type: String,
  },
  rating: {
    type: Number,
    min: 1,
    max: 5,
  },
  review: {
    type: String,
  },
})

// Compound index for efficient queries
learningProgressSchema.index({ user: 1, course: 1 }, { unique: true, sparse: true })
learningProgressSchema.index({ user: 1, material: 1 }, { unique: true, sparse: true })
learningProgressSchema.index({ user: 1, status: 1 })

export default mongoose.model("LearningProgress", learningProgressSchema)
