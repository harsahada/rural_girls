import mongoose from "mongoose"

const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    trim: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },
  password: {
    type: String,
    required: true,
    minlength: 6,
  },
  role: {
    type: String,
    enum: ["user", "mentor"],
    required: true,
  },
  profilePicture: {
    type: String, // File path for uploaded profile picture
  },
  // User-specific fields
  state: {
    type: String,
    required: function () {
      return this.role === "user"
    },
  },
  age: {
    type: Number,
    required: function () {
      return this.role === "user"
    },
  },
  language: {
    type: String,
    default: "English",
  },
  interests: [
    {
      type: String,
    },
  ],
  // Mentor-specific fields
  phone: {
    type: String,
    required: function () {
      return this.role === "mentor"
    },
  },
  jobTitle: {
    type: String,
    required: function () {
      return this.role === "mentor"
    },
  },
  experience: {
    type: String,
    required: function () {
      return this.role === "mentor"
    },
  },
  industry: {
    type: String,
  },
  goals: {
    type: String,
    required: function () {
      return this.role === "mentor"
    },
  },
  // Common fields
  isActive: {
    type: Boolean,
    default: true,
  },
  isApproved: {
    type: Boolean,
    default: function () {
      return this.role === "user" // Users are auto-approved, mentors need approval
    },
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

export default mongoose.model("User", userSchema)
