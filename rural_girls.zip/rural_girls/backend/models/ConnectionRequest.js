import mongoose from "mongoose"

const connectionRequestSchema = new mongoose.Schema({
  from: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  to: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  message: {
    type: String,
    trim: true,
  },
  requestType: {
    type: String,
    enum: ["mentorship", "collaboration", "networking", "other"],
    default: "mentorship",
  },
  status: {
    type: String,
    enum: ["pending", "accepted", "rejected"],
    default: "pending",
  },
  responseMessage: {
    type: String,
    trim: true,
  },
  respondedAt: {
    type: Date,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

export default mongoose.model("ConnectionRequest", connectionRequestSchema)
