import mongoose from "mongoose"

const studyMaterialSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
    required: true,
  },
  category: {
    type: String,
    required: true,
    enum: [
      "Business",
      "Arts & Crafts",
      "Agriculture",
      "Health & Wellness",
      "Communication Skills",
      "Digital Marketing",
      "Tailoring & Fashion",
      "Cooking & Food Processing",
      "Technology",
      "Education",
      "Other",
    ],
  },
  type: {
    type: String,
    required: true,
    enum: ["PDF", "Document", "Presentation", "Spreadsheet"],
  },
  difficulty: {
    type: String,
    enum: ["Beginner", "Intermediate", "Advanced"],
    default: "Beginner",
  },
  language: {
    type: String,
    default: "English",
  },
  tags: [
    {
      type: String,
      trim: true,
    },
  ],
  fileUrl: {
    type: String,
    required: true,
  },
  fileName: {
    type: String,
    required: true,
  },
  fileSize: {
    type: Number,
  },
  isPublic: {
    type: Boolean,
    default: true,
  },
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  likes: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  ],
  views: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

export default mongoose.model("StudyMaterial", studyMaterialSchema)
